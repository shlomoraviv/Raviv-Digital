/**
 * בודק כתיב חכם — Raviv Digital
 * content.js — רץ בתוך הדף (Gmail, או כל אתר שהמשתמש אישר דרך פופאפ ההרחבה).
 *
 * מה הוא עושה:
 * 1. עוקב אחרי שדה הטקסט האחרון שהיה בפוקוס (textarea / input / contenteditable).
 * 2. מיירט לחיצות על כפתורי "שלח/פרסם" (ו-Ctrl/Cmd+Enter) בשלב ה-capture,
 *    לפני שהאתר עצמו מספיק לטפל בהן.
 * 3. שולח את הטקסט ל-background.js לבדיקת כתיב מול Gemini API.
 * 4. אם נמצאו שגיאות — מציג חלונית תיקון מעוצבת (בתוך Shadow DOM מבודד),
 *    ומאפשר למשתמש לתקן ולשלוח, לשלוח כמו שזה, או לבטל.
 */

(() => {
  "use strict";

  const SEND_WORDS = [
    "שלח", "שליחה", "לשלוח", "פרסם", "פרסום", "לפרסם",
    "send", "post", "submit", "publish"
  ];

  const siteKey = location.hostname;
  let siteEnabled = true; // ברירת מחדל אופטימית עד שההגדרות נטענות
  let lastActiveEditable = null;
  let bypassEl = null;
  let uiRoot = null;
  let activeReq = 0; // מזהה בקשה פעילה — מאפשר להתעלם מתשובה אם המשתמש ויתר על הבדיקה
  let loadingTimer = null;

  // NodeBB (למשל mitmachim.top): כפתור השליחה של ה-composer הוא איקון בלבד, ללא טקסט,
  // ולכן מזהים אותו לפי class/attribute ולא לפי טקסט.
  // ה-class `composer-submit` אומת מול התבנית הרשמית של NodeBB. הסלקטור של quick-reply הוא best-effort.
  const NODEBB_SUBMIT_SELECTOR =
    '.composer-submit, [component="composer/submit"], [component="topic/quickreply/button"]';
  const NODEBB_COMPOSER_SELECTOR = '.composer-container, .composer, [component="composer"]';
  const TEXT_FIELD_SELECTOR =
    'textarea, input[type="text"], input[type="email"], input[type="search"], [contenteditable="true"]';

  /* ---------------------------- הגדרות אתר ---------------------------- */

  async function loadSiteEnabled() {
    try {
      const { sites } = await chrome.storage.local.get("sites");
      const entry = sites && sites[siteKey];
      siteEnabled = entry ? entry.enabled !== false : true;
    } catch (_) {
      siteEnabled = true;
    }
  }
  loadSiteEnabled();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.sites) return;
    const entry = changes.sites.newValue && changes.sites.newValue[siteKey];
    siteEnabled = entry ? entry.enabled !== false : true;
  });

  /* ------------------------------ עזרים ------------------------------ */

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }

  function isEditableEl(el) {
    if (!el) return false;
    if (el.tagName === "TEXTAREA") return true;
    if (el.tagName === "INPUT") return ["text", "email", "search"].includes(el.type);
    return !!el.isContentEditable;
  }

  function getTokens(label) {
    return label
      .replace(/[()\[\]{}.,:;!?"'׳״`\-–—]/g, " ")
      .split(/\s+/)
      .filter(Boolean);
  }

  function isSendLikeLabel(label) {
    if (!label) return false;
    const tokens = getTokens(label);
    return tokens.some((t) => {
      const lower = t.toLowerCase();
      return SEND_WORDS.some((w) => lower.includes(w));
    });
  }

  function findSendTrigger(target) {
    if (!(target instanceof Element)) return null;
    const nb = target.closest(NODEBB_SUBMIT_SELECTOR);
    if (nb && !nb.disabled && nb.getAttribute("aria-disabled") !== "true" && isVisible(nb)) return nb;
    const el = target.closest(
      'button, [role="button"], input[type="submit"], input[type="button"], a[role="button"]'
    );
    if (!el) return null;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return null;
    if (!isVisible(el)) return null;
    const label = (
      el.innerText || el.value || el.getAttribute("aria-label") || el.getAttribute("title") || ""
    ).trim();
    if (!isSendLikeLabel(label)) return null;
    return el;
  }

  function findAnySendButton(fields) {
    const anchor = fields && fields[0];
    if (anchor && anchor.closest) {
      const composer = anchor.closest(NODEBB_COMPOSER_SELECTOR);
      const nbBtn = composer && composer.querySelector(NODEBB_SUBMIT_SELECTOR);
      if (nbBtn && isVisible(nbBtn)) return nbBtn;
    }
    const all = Array.from(
      document.querySelectorAll(
        'button, [role="button"], input[type="submit"], input[type="button"], a[role="button"]'
      )
    );
    return (
      all.find((el) => {
        if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
        if (!isVisible(el)) return false;
        const label = (
          el.innerText || el.value || el.getAttribute("aria-label") || el.getAttribute("title") || ""
        ).trim();
        return isSendLikeLabel(label);
      }) || null
    );
  }

  function extractText(el) {
    if (!el) return "";
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return (el.value || "").trim();
    }
    if (el.isContentEditable) {
      const restore = [];
      if (siteKey === "mail.google.com") {
        // לא בודקים כתיב על ציטוטים של הודעות קודמות בשרשור
        el.querySelectorAll(".gmail_quote, .gmail_extra, .gmail_signature, blockquote").forEach((q) => {
          restore.push([q, q.style.display]);
          q.style.display = "none";
        });
      }
      const text = el.innerText || el.textContent || "";
      restore.forEach(([q, disp]) => {
        q.style.display = disp;
      });
      return text.replace(/\u00A0/g, " ").trim();
    }
    return "";
  }

  function pickEditableField(trigger) {
    let scope = trigger;
    for (let i = 0; i < 8 && scope && scope !== document.body; i++) {
      scope = scope.parentElement;
      if (!scope) break;
      const candidates = Array.from(
        scope.querySelectorAll(
          'textarea, input[type="text"], input[type="email"], input[type="search"], [contenteditable="true"]'
        )
      ).filter(isVisible);
      if (candidates.length) {
        if (lastActiveEditable && candidates.includes(lastActiveEditable)) return lastActiveEditable;
        return candidates.reduce(
          (best, c) => (extractText(c).length > extractText(best).length ? c : best),
          candidates[0]
        );
      }
    }
    if (lastActiveEditable && document.contains(lastActiveEditable) && isVisible(lastActiveEditable)) {
      return lastActiveEditable;
    }
    const all = Array.from(
      document.querySelectorAll(
        'textarea, input[type="text"], input[type="email"], input[type="search"], [contenteditable="true"]'
      )
    ).filter(isVisible);
    if (!all.length) return null;
    return all.reduce((best, c) => (extractText(c).length > extractText(best).length ? c : best), all[0]);
  }

  function getNodeBBFields(fromEl) {
    const composer = fromEl && fromEl.closest ? fromEl.closest(NODEBB_COMPOSER_SELECTOR) : null;
    if (!composer) return null;
    const fields = Array.from(composer.querySelectorAll(TEXT_FIELD_SELECTOR)).filter((el) => {
      if (!isVisible(el)) return false;
      // שדה התגיות אינו טקסט חופשי
      if (el.closest(".tags-container, .bootstrap-tagsinput, [component*='tag']")) return false;
      return true;
    });
    return fields.length ? fields : null;
  }

  // ב-NodeBB בודקים גם כותרת וגם גוף (כל השדות הגלויים ב-composer). בשאר האתרים — שדה אחד.
  function collectFields(trigger, activeEl) {
    const nb = getNodeBBFields(trigger || activeEl);
    if (nb) return nb;
    const single = trigger ? pickEditableField(trigger) : activeEl;
    return single ? [single] : [];
  }

  function cleanForCheck(text) {
    return (text || "")
      .replace(/```[\s\S]*?```/g, " ") // בלוקי קוד
      .replace(/^\s*>.*$/gm, " ") // ציטוטים
      .replace(/https?:\/\/\S+/g, " ") // קישורים
      .trim();
  }

  function extractFieldsText(fields) {
    return cleanForCheck(fields.map(extractText).filter(Boolean).join("\n\n"));
  }

  // החלפה עם גבולות מילה שמתאימים גם לעברית (\b של JS לא עובד על אותיות עבריות)
  function replaceWord(str, find, replace) {
    if (!find || !str.includes(find)) return str;
    const esc = find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp(`(?<![\\p{L}\\p{M}\\p{N}])${esc}(?![\\p{L}\\p{M}\\p{N}])`, "gu");
    return str.replace(re, () => replace);
  }

  function replaceInTextNodes(root, find, replace) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach((node) => {
      if (node.nodeValue && node.nodeValue.includes(find)) {
        node.nodeValue = replaceWord(node.nodeValue, find, replace);
      }
    });
  }

  function applyFixesToField(el, fixes) {
    if (!el || !fixes.length) return;
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      let val = el.value;
      fixes.forEach((f) => {
        val = replaceWord(val, f.wrong, f.correct);
      });
      if (val === el.value) return;
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement : HTMLInputElement;
      const setter = Object.getOwnPropertyDescriptor(proto.prototype, "value").set;
      setter.call(el, val);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (el.isContentEditable) {
      fixes.forEach((f) => replaceInTextNodes(el, f.wrong, f.correct));
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertReplacementText" }));
    }
  }

  function applyFixesToFields(fields, fixes) {
    fields.forEach((el) => applyFixesToField(el, fixes));
  }

  function sendMessageAsync(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          resolve(resp);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  /* ------------------------------ אייקונים ------------------------------ */

  const ICONS = {
    pencil: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`,
    check: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,
    close: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18"/><path d="M6 6l12 12"/></svg>`,
    arrowLeft: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="M11 18l-6-6 6-6"/></svg>`
  };

  /* -------------------------------- UI -------------------------------- */

  const CSS_TEXT = `
  .rd-overlay, .rd-toast { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; }
  .rd-overlay {
    position: fixed; inset: 0; z-index: 2147483647;
    background: rgba(15,17,26,.55); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    animation: rd-fade-in .18s ease; padding: 16px;
  }
  .rd-modal {
    width: min(480px, 100%); max-height: 82vh; overflow-y: auto;
    background: #fff; border-radius: 18px; padding: 22px 22px 18px;
    box-shadow: 0 24px 64px -12px rgba(20,23,31,.4), 0 4px 14px rgba(20,23,31,.1);
    animation: rd-pop-in .22s cubic-bezier(.2,.9,.3,1);
    color: #14171F; font-size: 14px; line-height: 1.5;
  }
  .rd-modal-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; margin-bottom: 16px; }
  .rd-header-main { display: flex; align-items: flex-start; gap: 12px; }
  .rd-modal-icon {
    width: 38px; height: 38px; flex-shrink: 0; border-radius: 11px; color: #fff;
    background: linear-gradient(135deg, #E23744, #FF6B5B);
    display: flex; align-items: center; justify-content: center;
  }
  .rd-modal-title { font-size: 16px; font-weight: 700; margin: 2px 0 3px; color: #14171F; }
  .rd-modal-subtitle { font-size: 12.5px; color: #6B7280; margin: 0; }
  .rd-icon-btn { width: 28px; height: 28px; flex-shrink: 0; border: none; border-radius: 8px; background: transparent; color: #6B7280; cursor: pointer; display: flex; align-items: center; justify-content: center; }
  .rd-icon-btn:hover { background: #F1F2F5; color: #14171F; }
  .rd-error-list { display: flex; flex-direction: column; gap: 8px; max-height: 300px; overflow-y: auto; margin-bottom: 16px; padding: 2px; }
  .rd-error-item { display: flex; align-items: flex-start; gap: 10px; padding: 10px 12px; border: 1px solid #E6E8EE; border-radius: 12px; background: #F7F8FA; cursor: pointer; transition: border-color .15s, background .15s; }
  .rd-error-item:has(.rd-error-check:checked) { border-color: #F3B7BC; background: #FFF6F6; }
  .rd-error-check { margin-top: 3px; width: 16px; height: 16px; accent-color: #E23744; flex-shrink: 0; cursor: pointer; }
  .rd-error-box { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
  .rd-word-wrong { color: #E23744; text-decoration: line-through; font-weight: 600; }
  .rd-arrow { color: #9AA1AE; display: inline-flex; }
  .rd-word-correct { color: #16A37A; font-weight: 700; }
  .rd-explain { flex-basis: 100%; font-size: 11.5px; color: #6B7280; }
  .rd-modal-actions { display: flex; gap: 8px; flex-wrap: wrap; }
  .rd-btn { border: none; border-radius: 999px; padding: 10px 16px; font-size: 13.5px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; font-family: inherit; transition: transform .1s ease, box-shadow .15s ease, background .15s ease; }
  .rd-btn:active { transform: scale(.96); }
  .rd-btn-primary { background: linear-gradient(135deg, #E23744, #FF6B5B); color: #fff; box-shadow: 0 6px 16px -4px rgba(226,55,68,.5); }
  .rd-btn-primary:hover { box-shadow: 0 8px 20px -4px rgba(226,55,68,.6); }
  .rd-btn-ghost { background: #F1F2F5; color: #14171F; }
  .rd-btn-ghost:hover { background: #E6E8EE; }
  .rd-btn-text { background: transparent; color: #6B7280; padding: 10px 8px; }
  .rd-btn-text:hover { color: #14171F; }
  .rd-modal-footer { display: flex; align-items: center; gap: 7px; margin-top: 14px; padding-top: 12px; border-top: 1px dashed #E6E8EE; font-size: 11px; color: #9AA1AE; }
  .rd-brand-mark { display: inline-flex; align-items: center; justify-content: center; width: 16px; height: 16px; border-radius: 5px; background: #1A2342; color: #fff; font-size: 9px; font-weight: 800; flex-shrink: 0; }
  .rd-modal-footer strong { color: #6B7280; }
  .rd-toast {
    position: fixed; top: 18px; left: 50%; z-index: 2147483647;
    transform: translateX(-50%) translateY(-10px); opacity: 0; pointer-events: none;
    background: #1A2342; color: #fff; padding: 10px 14px; border-radius: 16px; line-height: 1.4;
    font-size: 12.5px; display: flex; align-items: center; gap: 8px;
    box-shadow: 0 12px 28px -8px rgba(20,23,31,.45);
    transition: opacity .18s ease, transform .18s ease; max-width: min(92vw, 540px);
  }
  .rd-toast.rd-show { opacity: 1; transform: translateX(-50%) translateY(0); pointer-events: auto; }
  .rd-toast.rd-warning { background: #B4530F; }
  .rd-toast.rd-success { background: #128A6B; }
  .rd-toast-actions { display: flex; gap: 6px; }
  .rd-toast-btn { background: rgba(255,255,255,.18); border: none; color: #fff; padding: 5px 10px; border-radius: 999px; font-size: 11.5px; cursor: pointer; font-family: inherit; }
  .rd-toast-btn:hover { background: rgba(255,255,255,.3); }
  .rd-toast-btn-primary { background: #fff; color: #1A2342; font-weight: 700; }
  .rd-toast-btn-primary:hover { background: #F1F2F5; }
  .rd-spinner { width: 13px; height: 13px; border-radius: 50%; border: 2px solid rgba(255,255,255,.35); border-top-color: #fff; animation: rd-spin .7s linear infinite; flex-shrink: 0; }
  .rd-toast-icon { display: inline-flex; }
  @keyframes rd-spin { to { transform: rotate(360deg); } }
  @keyframes rd-fade-in { from { opacity: 0; } to { opacity: 1; } }
  @keyframes rd-pop-in { from { opacity: 0; transform: translateY(8px) scale(.97); } to { opacity: 1; transform: translateY(0) scale(1); } }
  @media (max-width: 480px) { .rd-modal { padding: 18px 16px 16px; } }
  @media (prefers-reduced-motion: reduce) { .rd-overlay, .rd-modal, .rd-toast, .rd-spinner { animation-duration: .001ms !important; transition-duration: .001ms !important; } }
  `;

  function ensureUI() {
    if (uiRoot) return uiRoot;
    const host = document.createElement("div");
    host.id = "raviv-spellcheck-host";
    document.documentElement.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CSS_TEXT;
    shadow.appendChild(style);
    const slot = document.createElement("div");
    slot.id = "rd-slot";
    slot.setAttribute("dir", "rtl");
    shadow.appendChild(slot);
    uiRoot = { host, shadow, slot };
    return uiRoot;
  }

  function getToastEl() {
    const { slot } = ensureUI();
    let toast = slot.querySelector("#rd-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "rd-toast";
      toast.className = "rd-toast";
      slot.appendChild(toast);
    }
    return toast;
  }

  function hideToast() {
    clearTimeout(loadingTimer);
    const { slot } = ensureUI();
    const toast = slot.querySelector("#rd-toast");
    if (toast) toast.className = "rd-toast";
  }

  function showLoadingToast(onSkip) {
    clearTimeout(loadingTimer);
    const toast = getToastEl();
    toast.className = "rd-toast rd-show";
    toast.innerHTML = `<span class="rd-spinner"></span><span>בודק כתיב…</span>`;
    // אם הבדיקה מתארכת — נותנים למשתמש לדלג ולא להיתקע
    loadingTimer = setTimeout(() => {
      const t = getToastEl();
      if (!t.classList.contains("rd-show") || !t.querySelector(".rd-spinner")) return;
      t.innerHTML =
        `<span class="rd-spinner"></span><span>הבדיקה לוקחת יותר מהרגיל…</span>` +
        `<span class="rd-toast-actions"><button class="rd-toast-btn rd-toast-btn-primary" data-skip>שלח בלי בדיקה</button></span>`;
      t.querySelector("[data-skip]").addEventListener("click", () => {
        hideToast();
        onSkip();
      });
    }, 3000);
  }

  function showSuccessToastThenSend(trigger, fields) {
    const toast = getToastEl();
    toast.className = "rd-toast rd-show rd-success";
    toast.innerHTML = `<span class="rd-toast-icon">${ICONS.check}</span><span>אין שגיאות כתיב · שולח…</span>`;
    setTimeout(() => {
      hideToast();
      triggerRealSend(trigger, fields);
    }, 600);
  }

  function showActionToast(message, actions) {
    const toast = getToastEl();
    toast.className = "rd-toast rd-show rd-warning";
    const btns = actions
      .map((a, i) => `<button class="rd-toast-btn ${a.primary ? "rd-toast-btn-primary" : ""}" data-i="${i}">${escapeHtml(a.label)}</button>`)
      .join("");
    toast.innerHTML = `<span>${escapeHtml(message)}</span><span class="rd-toast-actions">${btns}</span>`;
    actions.forEach((a, i) => {
      const btn = toast.querySelector(`[data-i="${i}"]`);
      if (btn) {
        btn.addEventListener("click", () => {
          hideToast();
          a.onClick && a.onClick();
        });
      }
    });
  }

  function showErrorsModal(errors, fields, trigger) {
    const { slot } = ensureUI();
    let container = slot.querySelector("#rd-modal-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "rd-modal-container";
      slot.appendChild(container);
    }

    const rows = errors
      .map(
        (err, i) => `
      <label class="rd-error-item">
        <input type="checkbox" class="rd-error-check" data-idx="${i}" checked />
        <span class="rd-error-box">
          <span class="rd-word-wrong">${escapeHtml(err.wrong)}</span>
          <span class="rd-arrow">${ICONS.arrowLeft}</span>
          <span class="rd-word-correct">${escapeHtml(err.correct)}</span>
          ${err.explanation ? `<span class="rd-explain">${escapeHtml(err.explanation)}</span>` : ""}
        </span>
      </label>`
      )
      .join("");

    container.innerHTML = `
      <div class="rd-overlay">
        <div class="rd-modal" role="dialog" aria-modal="true" aria-labelledby="rd-title">
          <div class="rd-modal-header">
            <div class="rd-header-main">
              <div class="rd-modal-icon">${ICONS.pencil}</div>
              <div>
                <h2 id="rd-title" class="rd-modal-title">נמצאו שגיאות כתיב</h2>
                <p class="rd-modal-subtitle">${errors.length} ${errors.length === 1 ? "שגיאה נמצאה" : "שגיאות נמצאו"} בטקסט לפני השליחה</p>
              </div>
            </div>
            <button class="rd-icon-btn" data-action="cancel" aria-label="סגור">${ICONS.close}</button>
          </div>
          <div class="rd-error-list">${rows}</div>
          <div class="rd-modal-actions">
            <button class="rd-btn rd-btn-primary" data-action="fix-send">${ICONS.check}<span>תקן ושלח</span></button>
            <button class="rd-btn rd-btn-ghost" data-action="send-anyway"><span>שלח כמו שזה</span></button>
            <button class="rd-btn rd-btn-text" data-action="cancel"><span>ביטול</span></button>
          </div>
          <div class="rd-modal-footer"><span class="rd-brand-mark">רד</span><span>נבדק ע״י AI · תוסף בודק כתיב מבית <strong>רביב דיגיטל</strong></span></div>
        </div>
      </div>`;

    const overlay = container.querySelector(".rd-overlay");
    const onEsc = (e) => {
      if (e.key === "Escape") closeAll();
    };
    function closeAll() {
      container.innerHTML = "";
      document.removeEventListener("keydown", onEsc, true);
    }
    document.addEventListener("keydown", onEsc, true);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeAll();
    });

    container.querySelectorAll("[data-action]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const action = btn.getAttribute("data-action");
        if (action === "cancel") {
          closeAll();
        } else if (action === "send-anyway") {
          closeAll();
          triggerRealSend(trigger, fields);
        } else if (action === "fix-send") {
          const fixes = [];
          container.querySelectorAll(".rd-error-check").forEach((chk) => {
            if (chk.checked) fixes.push(errors[Number(chk.getAttribute("data-idx"))]);
          });
          closeAll();
          applyFixesToFields(fields, fixes);
          setTimeout(() => triggerRealSend(trigger, fields), 60);
        }
      });
    });

    setTimeout(() => container.querySelector(".rd-btn-primary")?.focus(), 20);
  }

  /* --------------------------- לוגיקת שליחה --------------------------- */

  function triggerRealSend(trigger, fields) {
    const btn = trigger && document.contains(trigger) ? trigger : findAnySendButton(fields);
    if (btn) {
      bypassEl = btn;
      btn.click();
      setTimeout(() => {
        if (bypassEl === btn) bypassEl = null;
      }, 150);
    } else {
      showActionToast("לא נמצא כפתור שליחה — יש ללחוץ שוב באופן ידני", []);
    }
  }

  function handleCheckFailure(response, trigger, fields, text) {
    const reason = response && response.reason;
    const msg = (response && response.userMessage) || "בדיקת הכתיב נכשלה";
    const sendAnyway = { label: "שלח בכל זאת", primary: true, onClick: () => triggerRealSend(trigger, fields) };
    if (reason === "no-key" || reason === "bad-key") {
      showActionToast(msg, [
        { label: "פתח הגדרות", onClick: () => chrome.runtime.sendMessage({ type: "OPEN_OPTIONS" }) },
        sendAnyway
      ]);
    } else {
      showActionToast(msg, [
        { label: "נסה שוב", onClick: () => handleInterceptedSend(trigger, fields, text) },
        sendAnyway
      ]);
    }
  }

  async function handleInterceptedSend(trigger, fields, text) {
    const myReq = ++activeReq;
    showLoadingToast(() => {
      activeReq++; // מבטל את התשובה שעוד תגיע
      triggerRealSend(trigger, fields);
    });
    let response;
    try {
      response = await sendMessageAsync({ type: "CHECK_SPELLING", text });
    } catch (e) {
      response = { ok: false, reason: "network-error", userMessage: "ההרחבה לא זמינה — רעננו את הדף", message: String(e) };
    }
    if (myReq !== activeReq) return; // המשתמש ויתר על הבדיקה
    hideToast();

    if (!response || !response.ok) {
      handleCheckFailure(response, trigger, fields, text);
      return;
    }
    if (!response.hasErrors || !response.errors || !response.errors.length) {
      showSuccessToastThenSend(trigger, fields);
      return;
    }
    showErrorsModal(response.errors, fields, trigger);
  }

  /* ------------------------------ מאזינים ------------------------------ */

  document.addEventListener(
    "focusin",
    (e) => {
      if (isEditableEl(e.target)) lastActiveEditable = e.target;
    },
    true
  );

  document.addEventListener(
    "click",
    (e) => {
      if (!siteEnabled) return;
      const trigger = findSendTrigger(e.target);
      if (!trigger) return;
      if (bypassEl && trigger === bypassEl) {
        bypassEl = null;
        return;
      }
      const fields = collectFields(trigger, null);
      const text = extractFieldsText(fields);
      if (!text || text.length < 3) return;
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      handleInterceptedSend(trigger, fields, text);
    },
    true
  );

  document.addEventListener(
    "keydown",
    (e) => {
      if (!siteEnabled) return;
      if (!((e.ctrlKey || e.metaKey) && e.key === "Enter")) return;
      const active = document.activeElement;
      if (!isEditableEl(active)) return;
      const fields = collectFields(null, active);
      const text = extractFieldsText(fields);
      if (!text || text.length < 3) return;
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      handleInterceptedSend(null, fields, text);
    },
    true
  );
})();
