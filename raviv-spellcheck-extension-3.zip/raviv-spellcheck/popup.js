/**
 * בודק כתיב חכם — Raviv Digital
 * popup.js
 */

function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs && tabs[0]));
  });
}

async function init() {
  const siteNameEl = document.getElementById("site-name");
  const siteStatusEl = document.getElementById("site-status");
  const toggleEl = document.getElementById("site-toggle");
  const toggleWrap = document.getElementById("toggle-wrap");
  const enableBtn = document.getElementById("enable-site-btn");
  const keyStatusEl = document.getElementById("key-status");
  const keyDotEl = document.getElementById("key-dot");

  const tab = await getActiveTab();
  let hostname = null;
  try {
    hostname = tab && tab.url ? new URL(tab.url).hostname : null;
  } catch (_) {}

  const isWebPage = hostname && /^https?:/i.test(tab.url || "");

  if (!isWebPage) {
    siteNameEl.textContent = "אין עמוד פעיל";
    siteStatusEl.textContent = "התוסף פועל בדפי אינטרנט רגילים בלבד";
    toggleWrap.style.display = "none";
    enableBtn.style.display = "none";
  } else {
    siteNameEl.textContent = hostname;
    const sites = await RDSites.getSites();
    const isGmail = hostname === "mail.google.com";
    const entry = sites[hostname];

    if (entry || isGmail) {
      const enabled = entry ? entry.enabled !== false : true;
      toggleWrap.style.display = "";
      enableBtn.style.display = "none";
      toggleEl.checked = enabled;
      siteStatusEl.textContent = enabled ? "פעיל באתר זה" : "מושהה באתר זה";

      toggleEl.addEventListener("change", async () => {
        await RDSites.toggleSite(hostname, toggleEl.checked);
        siteStatusEl.textContent = toggleEl.checked ? "פעיל באתר זה" : "מושהה באתר זה";
      });
    } else {
      toggleWrap.style.display = "none";
      siteStatusEl.textContent = "לא פעיל באתר זה עדיין";
      enableBtn.style.display = "";

      enableBtn.addEventListener("click", async () => {
        enableBtn.disabled = true;
        enableBtn.textContent = "מבקש הרשאה…";
        const res = await RDSites.requestAndRegisterSite(hostname);
        if (res.ok) {
          try {
            await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
          } catch (_) {}
          enableBtn.style.display = "none";
          toggleWrap.style.display = "";
          toggleEl.checked = true;
          siteStatusEl.textContent = "פעיל באתר זה ✓";
        } else {
          enableBtn.disabled = false;
          enableBtn.textContent = "הפעל באתר הזה";
          siteStatusEl.textContent = res.error || "משהו השתבש, נסו שוב";
        }
      });
    }
  }

  const { apiKey } = await chrome.storage.local.get("apiKey");
  if (apiKey) {
    keyStatusEl.textContent = "מוגדר ✓";
    keyDotEl.className = "dot on";
  } else {
    keyStatusEl.textContent = "לא הוגדר — לחצו כדי להגדיר";
    keyDotEl.className = "dot off";
  }

  document.getElementById("open-options-btn").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
  document.getElementById("key-card").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}

document.addEventListener("DOMContentLoaded", init);
