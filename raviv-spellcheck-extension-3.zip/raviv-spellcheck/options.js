/**
 * בודק כתיב חכם — Raviv Digital
 * options.js
 */

const DEFAULT_MODEL = "gemini-3.5-flash-lite";
const BUILT_IN_MODELS = ["gemini-3.5-flash-lite", "gemini-3.6-flash", "gemini-flash-latest"];

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function loadSettings() {
  const { apiKey, model } = await chrome.storage.local.get(["apiKey", "model"]);
  document.getElementById("api-key").value = apiKey || "";

  const select = document.getElementById("model-select");
  const customGroup = document.getElementById("custom-model-group");
  const customInput = document.getElementById("custom-model");

  if (model && !BUILT_IN_MODELS.includes(model)) {
    select.value = "custom";
    customInput.value = model;
    customGroup.style.display = "";
  } else {
    select.value = model || DEFAULT_MODEL;
    customGroup.style.display = "none";
  }
}

function wireModelSelect() {
  const select = document.getElementById("model-select");
  const customGroup = document.getElementById("custom-model-group");
  select.addEventListener("change", () => {
    customGroup.style.display = select.value === "custom" ? "" : "none";
  });
}

function wireKeyVisibility() {
  const btn = document.getElementById("toggle-key-visibility");
  const input = document.getElementById("api-key");
  btn.addEventListener("click", () => {
    input.type = input.type === "password" ? "text" : "password";
  });
}

async function saveSettings() {
  const apiKey = document.getElementById("api-key").value.trim();
  const select = document.getElementById("model-select");
  const custom = document.getElementById("custom-model").value.trim();
  const model = select.value === "custom" ? custom || DEFAULT_MODEL : select.value;
  await chrome.storage.local.set({ apiKey, model, modelMigratedV2: true });
}

function wireSave() {
  const btn = document.getElementById("save-btn");
  const msg = document.getElementById("save-msg");
  btn.addEventListener("click", async () => {
    await saveSettings();
    msg.classList.add("show");
    setTimeout(() => msg.classList.remove("show"), 2200);
  });
}

function wireTest() {
  const btn = document.getElementById("test-btn");
  const out = document.getElementById("test-msg");
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    await saveSettings();
    out.className = "test-msg";
    out.textContent = "בודק חיבור…";
    const t0 = performance.now();
    let res;
    try {
      res = await chrome.runtime.sendMessage({
        type: "CHECK_SPELLING",
        noCache: true,
        text: "אני רוצה לשלוח הודעה עם שגיעה בכתיב."
      });
    } catch (e) {
      res = { ok: false, userMessage: String(e) };
    }
    const sec = ((performance.now() - t0) / 1000).toFixed(1);
    btn.disabled = false;
    if (res && res.ok) {
      const found = res.hasErrors ? ` · זוהו ${res.errors.length} שגיאות בטקסט הבדיקה` : " · לא זוהו שגיאות בטקסט הבדיקה (מצופה שגיאה אחת)";
      out.className = "test-msg ok";
      out.textContent = `החיבור תקין ✓ · זמן תגובה: ${sec} שניות${found}`;
    } else {
      out.className = "test-msg err";
      out.textContent = `נכשל אחרי ${sec} שניות: ${(res && res.userMessage) || "שגיאה לא ידועה"}`;
    }
  });
}

async function renderSites() {
  const list = document.getElementById("sites-list");
  const sites = await RDSites.getSites();
  const hosts = Object.keys(sites).sort((a, b) => (a === "mail.google.com" ? -1 : b === "mail.google.com" ? 1 : a.localeCompare(b)));

  list.innerHTML = hosts
    .map((host) => {
      const entry = sites[host];
      const enabled = entry.enabled !== false;
      const isBuiltin = !!entry.builtin;
      return `
      <div class="site-row" data-host="${escapeHtml(host)}">
        <div class="site-name">
          ${escapeHtml(host)}
          ${isBuiltin ? '<span class="site-badge">מובנה</span>' : ""}
        </div>
        <div class="site-actions">
          <label class="switch">
            <input type="checkbox" class="site-toggle" ${enabled ? "checked" : ""} />
            <span class="slider"></span>
          </label>
          ${
            isBuiltin
              ? ""
              : `<button class="btn-danger-ghost site-remove" type="button" aria-label="הסרה">
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                </button>`
          }
        </div>
      </div>`;
    })
    .join("");

  if (!hosts.length) {
    list.innerHTML = `<p class="empty-hint">אין עדיין אתרים מוגדרים.</p>`;
  }

  list.querySelectorAll(".site-row").forEach((row) => {
    const host = row.getAttribute("data-host");
    const toggle = row.querySelector(".site-toggle");
    toggle.addEventListener("change", async () => {
      await RDSites.toggleSite(host, toggle.checked);
    });
    const removeBtn = row.querySelector(".site-remove");
    if (removeBtn) {
      removeBtn.addEventListener("click", async () => {
        removeBtn.disabled = true;
        await RDSites.removeSite(host);
        renderSites();
      });
    }
  });
}

function wireAddSite() {
  const input = document.getElementById("new-site-input");
  const btn = document.getElementById("add-site-btn");
  const status = document.getElementById("add-status");

  async function doAdd() {
    const value = input.value.trim();
    if (!value) return;
    btn.disabled = true;
    status.textContent = "מבקש הרשאה לאתר…";
    status.className = "add-status";

    const res = await RDSites.requestAndRegisterSite(value);
    btn.disabled = false;

    if (res.ok) {
      input.value = "";
      status.textContent = `${res.host} נוסף בהצלחה — יופעל אוטומטית בביקור הבא באתר`;
      status.className = "add-status success";
      renderSites();
    } else {
      status.textContent = res.error || "משהו השתבש, נסו שוב";
      status.className = "add-status error";
    }
  }

  btn.addEventListener("click", doAdd);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") doAdd();
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  wireModelSelect();
  wireKeyVisibility();
  wireSave();
  wireTest();
  wireAddSite();
  await loadSettings();
  await renderSites();
});
