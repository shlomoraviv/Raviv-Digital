/**
 * בודק כתיב חכם — Raviv Digital
 * background.js — Service worker: תקשורת מול Gemini API (Google AI Studio).
 *
 * מהירות: מודלי Gemini 3.x חושבים כברירת מחדל (רמת "medium"), וזה מאט משמעותית בדיקה פשוטה כמו הגהה.
 * לכן: ברירת המחדל היא Flash-Lite (חשיבה מינימלית), ובשאר המודלים נשלח thinkingLevel=low.
 */

const DEFAULT_MODEL = "gemini-3.5-flash-lite";
const API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const MAX_CHARS = 15000;
const TIMEOUT_MS = 15000;
const CACHE_MAX = 30;
const cache = new Map(); // תוצאות לטקסטים זהים (למשל ביטול ושליחה חוזרת)

const SYSTEM_INSTRUCTION = `אתה עוזר הגהה מקצועי בעברית.
תפקידך היחיד: לאתר שגיאות כתיב/איות אמיתיות בטקסט הנתון — כלומר מילים שכתובות בצורה שגויה.
הטקסט עשוי להיות הודעת מייל או פוסט בפורום (כותרת וגוף יחד), ועשוי לכלול סימני Markdown.
אל תסמן: שגיאות תחביר, ניקוד, פיסוק, סגנון, משלב לשוני, שמות פרטיים/מותגים, ראשי תיבות וקיצורים מקובלים (למשל בס"ד, בעז"ה, וכו'), מונחים טכניים ומילים באנגלית שכתובות נכון, כינויי משתמשים (@...), כתובות אתר או מייל, קוד וסימני Markdown.
אם מילה יכולה להיות תקינה בהקשר מסוים (למשל סלנג נפוץ, קיצור מקובל) — אל תסמן אותה.
עבור כל שגיאה החזר את המילה בדיוק כפי שהיא מופיעה בטקסט המקורי, פעם אחת בלבד ברשימה.
החזר JSON בלבד, בפורמט: {"hasErrors": true|false, "errors": [{"wrong": "...", "correct": "..."}]}
אם אין שגיאות: {"hasErrors": false, "errors": []}`;

const RESPONSE_SCHEMA = {
  type: "OBJECT",
  properties: {
    hasErrors: { type: "BOOLEAN" },
    errors: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          wrong: { type: "STRING" },
          correct: { type: "STRING" }
        },
        required: ["wrong", "correct"]
      }
    }
  },
  required: ["hasErrors", "errors"]
};

/* ------------------------- התקנה / הגדרות ברירת מחדל ------------------------- */

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(["model", "sites", "modelMigratedV2"]);
  const patch = {};
  // מעבר חד-פעמי: ברירת המחדל הקודמת (gemini-flash-latest) הייתה איטית
  if (!cur.model || (cur.model === "gemini-flash-latest" && !cur.modelMigratedV2)) patch.model = DEFAULT_MODEL;
  if (!cur.modelMigratedV2) patch.modelMigratedV2 = true;
  if (!cur.sites) {
    patch.sites = {
      "mail.google.com": { enabled: true, builtin: true },
      "mitmachim.top": { enabled: true, builtin: true },
      "bnebrak.com": { enabled: true, builtin: true },
      "bina.top": { enabled: true, builtin: true }
    };
  }
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
});

/* ------------------------------- עזרים ------------------------------- */

function thinkingConfigFor(model) {
  const m = (model || "").toLowerCase();
  if (m.includes("lite")) return null; // Flash-Lite: חשיבה מינימלית כברירת מחדל
  if (m.includes("2.5")) return { thinkingBudget: 0 };
  return { thinkingLevel: "low" };
}

function buildBody(text, model, level) {
  const generationConfig = { responseMimeType: "application/json", maxOutputTokens: 4096 };
  if (level === "full") {
    generationConfig.responseSchema = RESPONSE_SCHEMA;
    const t = thinkingConfigFor(model);
    if (t) generationConfig.thinkingConfig = t;
  }
  return {
    systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
    contents: [{ role: "user", parts: [{ text: `בדוק שגיאות כתיב בטקסט הבא:\n\n"""\n${text}\n"""` }] }],
    generationConfig
  };
}

async function callGemini(apiKey, model, body) {
  const url = `${API_BASE}/${encodeURIComponent(model)}:generateContent`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!resp.ok) {
      let message = "";
      try {
        message = (await resp.json())?.error?.message || "";
      } catch (_) {}
      return { ok: false, status: resp.status, message };
    }
    return { ok: true, data: await resp.json() };
  } catch (err) {
    return { ok: false, kind: err && err.name === "AbortError" ? "timeout" : "network", message: err?.message || "" };
  } finally {
    clearTimeout(timer);
  }
}

const short = (s) => (s || "").replace(/\s+/g, " ").slice(0, 90);
const isKeyError = (msg) => /api key|api_key|key.*(invalid|expired)|invalid.*key/i.test(msg || "");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function describeFailure(res) {
  if (res.kind === "timeout") return { reason: "timeout", userMessage: "הבדיקה ארכה יותר מדי" };
  if (res.kind === "network") return { reason: "network-error", userMessage: "אין חיבור ל-Gemini — בדקו את האינטרנט" };
  const s = res.status;
  if ((s === 400 && isKeyError(res.message)) || s === 401 || s === 403) {
    return { reason: "bad-key", userMessage: "מפתח ה-API נדחה" + (res.message ? `: ${short(res.message)}` : "") };
  }
  if (s === 404) return { reason: "not-found", userMessage: "המודל לא נמצא — בחרו מודל אחר בהגדרות" };
  if (s === 429) return { reason: "rate-limit", userMessage: "חרגתם ממכסת ה-API — נסו שוב בעוד רגע" };
  if (s >= 500) return { reason: "server", userMessage: "שרת Gemini עמוס כרגע" };
  return { reason: "api-error", userMessage: `שגיאת Gemini (${s})` + (res.message ? `: ${short(res.message)}` : "") };
}

function parseModelOutput(data) {
  const parts = data?.candidates?.[0]?.content?.parts || [];
  let raw = parts.filter((p) => !p.thought).map((p) => p.text || "").join("").trim();
  if (!raw) return null;
  raw = raw.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(raw);
  } catch (_) {
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return null;
    try {
      return JSON.parse(m[0]);
    } catch (_) {
      return null;
    }
  }
}

/* ---------------------------- הבדיקה עצמה ---------------------------- */

async function checkSpelling(rawText, noCache) {
  const started = Date.now();
  const { apiKey, model } = await chrome.storage.local.get(["apiKey", "model"]);
  if (!apiKey) return { ok: false, reason: "no-key", userMessage: "לא הוגדר מפתח API לבדיקת כתיב" };

  let text = (rawText || "").trim();
  const truncated = text.length > MAX_CHARS;
  if (truncated) text = text.slice(0, MAX_CHARS);
  if (!/\p{L}{2,}/u.test(text)) return { ok: true, hasErrors: false, errors: [], ms: 0 };

  const useModel = model || DEFAULT_MODEL;
  const cacheKey = `${useModel}|${text}`;
  if (!noCache && cache.has(cacheKey)) return { ...cache.get(cacheKey), cached: true, ms: 0 };

  let res = await callGemini(apiKey, useModel, buildBody(text, useModel, "full"));

  // 400 שאינו בעיית מפתח (למשל פרמטר שהמודל לא תומך בו) — ניסיון חוזר בבקשה בסיסית
  if (!res.ok && res.status === 400 && !isKeyError(res.message)) {
    res = await callGemini(apiKey, useModel, buildBody(text, useModel, "basic"));
  }
  // עומס/מכסה רגעיים — ניסיון חוזר אחד
  if (!res.ok && [429, 500, 502, 503, 504].includes(res.status)) {
    await sleep(700);
    res = await callGemini(apiKey, useModel, buildBody(text, useModel, "full"));
  }

  if (!res.ok) return { ok: false, ...describeFailure(res), message: res.message, ms: Date.now() - started };

  const parsed = parseModelOutput(res.data);
  if (!parsed) {
    return { ok: false, reason: "parse-error", userMessage: "המודל לא החזיר תשובה תקינה", ms: Date.now() - started };
  }

  const errors = (Array.isArray(parsed.errors) ? parsed.errors : []).filter(
    (e) => e && e.wrong && e.correct && e.wrong !== e.correct && text.includes(e.wrong)
  );
  const result = { ok: true, hasErrors: errors.length > 0, errors, truncated };
  if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
  cache.set(cacheKey, result);
  return { ...result, ms: Date.now() - started };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return false;
  if (message.type === "OPEN_OPTIONS") {
    chrome.runtime.openOptionsPage();
    return false;
  }
  if (message.type === "CHECK_SPELLING") {
    checkSpelling(message.text, !!message.noCache)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, reason: "network-error", userMessage: "שגיאה לא צפויה בבדיקה", message: String(err) }));
    return true;
  }
  return false;
});
