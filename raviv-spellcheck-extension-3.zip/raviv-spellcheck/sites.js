/**
 * בודק כתיב חכם — Raviv Digital
 * sites.js — לוגיקה משותפת לניהול אתרים (popup.js + options.js).
 * טעינה כ-<script> רגיל (לא module) כדי לפשט את מבנה התוסף.
 */

const RDSites = (() => {
  function normalizeHostname(input) {
    let v = (input || "").trim();
    if (!v) return null;
    v = v.replace(/^https?:\/\//i, "").replace(/\/.*$/, "").replace(/^www\./i, "");
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(v)) return null;
    return v.toLowerCase();
  }

  // אתרים מובנים (מוגדרים ב-manifest ופעילים מהרגע הראשון)
  const BUILTIN = {
    "mail.google.com": { enabled: true, builtin: true },
    "mitmachim.top": { enabled: true, builtin: true },
    "bnebrak.com": { enabled: true, builtin: true },
    "bina.top": { enabled: true, builtin: true }
  };

  async function getSites() {
    const { sites } = await chrome.storage.local.get("sites");
    const merged = { ...BUILTIN };
    Object.keys(sites || {}).forEach((h) => {
      merged[h] = { ...(BUILTIN[h] || {}), ...sites[h] };
    });
    return merged;
  }

  async function setSites(sites) {
    await chrome.storage.local.set({ sites });
  }

  async function requestAndRegisterSite(hostname) {
    const host = normalizeHostname(hostname);
    if (!host) return { ok: false, error: "כתובת האתר לא תקינה" };
    if (BUILTIN[host]) return { ok: false, error: "האתר הזה כבר פעיל כברירת מחדל" };

    const pattern = `*://${host}/*`;
    let granted;
    try {
      granted = await chrome.permissions.request({ origins: [pattern] });
    } catch (e) {
      return { ok: false, error: "הבקשה נכשלה: " + e.message };
    }
    if (!granted) return { ok: false, error: "ההרשאה נדחתה" };

    try {
      const existing = await chrome.scripting
        .getRegisteredContentScripts({ ids: [`site-${host}`] })
        .catch(() => []);
      if (!existing.length) {
        await chrome.scripting.registerContentScripts([
          { id: `site-${host}`, matches: [pattern], js: ["content.js"], runAt: "document_idle" }
        ]);
      }
    } catch (e) {
      return { ok: false, error: "רישום ההרחבה לאתר נכשל: " + e.message };
    }

    const sites = await getSites();
    sites[host] = { enabled: true, pattern, builtin: false };
    await setSites(sites);
    return { ok: true, host };
  }

  async function removeSite(host) {
    try {
      await chrome.scripting.unregisterContentScripts({ ids: [`site-${host}`] });
    } catch (_) {}
    try {
      await chrome.permissions.remove({ origins: [`*://${host}/*`] });
    } catch (_) {}
    const sites = await getSites();
    delete sites[host];
    await setSites(sites);
  }

  async function toggleSite(host, enabled) {
    const sites = await getSites();
    if (!sites[host]) sites[host] = { enabled, builtin: !!BUILTIN[host] };
    else sites[host].enabled = enabled;
    await setSites(sites);
  }

  return { normalizeHostname, getSites, setSites, requestAndRegisterSite, removeSite, toggleSite };
})();
