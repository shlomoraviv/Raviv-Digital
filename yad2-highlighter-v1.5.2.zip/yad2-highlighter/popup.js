const VIEWED_KEY = 'y2h_viewed';
const SETTINGS_KEY = 'y2h_settings';
const HIDDEN_KEY = 'y2h_hidden';
const HIDE_COMMERCIAL_KEY = 'y2h_hide_commercial';
const DEFAULTS = { color: '#ffd400', size: 6, markStyle: 'full' };

const colorInput = document.getElementById('colorInput');
const sizeInput = document.getElementById('sizeInput');
const sizeValue = document.getElementById('sizeValue');
const countValue = document.getElementById('countValue');
const resetBtn = document.getElementById('resetBtn');
const mockCard = document.getElementById('mockCard');
const colorSizeControls = document.getElementById('colorSizeControls');
const markStyleInputs = Array.from(document.querySelectorAll('input[name="markStyle"]'));
const hideCommercialToggle = document.getElementById('hideCommercialToggle');
const hiddenCountValue = document.getElementById('hiddenCountValue');
const unhideBtn = document.getElementById('unhideBtn');
const openOptionsBtn = document.getElementById('openOptionsBtn');

function applyPreview(settings) {
  document.documentElement.style.setProperty('--accent', settings.color);
  mockCard.style.setProperty('--mock-color', settings.color);
  mockCard.style.setProperty('--mock-size', settings.size + 'px');
  sizeValue.textContent = settings.size + 'px';

  const isCheckOnly = settings.markStyle === 'checkOnly';
  mockCard.classList.toggle('mock-card--check-only', isCheckOnly);
  // צבע/עובי לא משפיעים על שום דבר במצב "רק V" - מעמעמים את הבקרות שלהם
  // כדי שלא ייראה כאילו הן "לא עובדות" כשמזיזים אותן בלי אפקט גלוי.
  colorSizeControls.classList.toggle('is-inactive', isCheckOnly);
}

function currentSettings() {
  const checkedMarkStyle = markStyleInputs.find((el) => el.checked);
  return {
    color: colorInput.value,
    size: Number(sizeInput.value),
    markStyle: checkedMarkStyle ? checkedMarkStyle.value : DEFAULTS.markStyle,
  };
}

function saveSettings(settings) {
  chrome.storage.local.set({ [SETTINGS_KEY]: settings });
}

function loadCount() {
  chrome.storage.local.get(VIEWED_KEY, (res) => {
    const map = res[VIEWED_KEY] || {};
    countValue.textContent = Object.keys(map).length.toLocaleString('he-IL');
  });
}

function loadHiddenCount() {
  chrome.storage.local.get(HIDDEN_KEY, (res) => {
    const map = res[HIDDEN_KEY] || {};
    hiddenCountValue.textContent = Object.keys(map).length.toLocaleString('he-IL');
  });
}

chrome.storage.local.get(SETTINGS_KEY, (res) => {
  const settings = { ...DEFAULTS, ...(res[SETTINGS_KEY] || {}) };
  colorInput.value = settings.color;
  sizeInput.value = String(settings.size);
  markStyleInputs.forEach((el) => {
    el.checked = el.value === settings.markStyle;
  });
  applyPreview(settings);
});

chrome.storage.local.get(HIDE_COMMERCIAL_KEY, (res) => {
  hideCommercialToggle.checked = Boolean(res[HIDE_COMMERCIAL_KEY]);
});

loadCount();
loadHiddenCount();

hideCommercialToggle.addEventListener('change', () => {
  chrome.storage.local.set({ [HIDE_COMMERCIAL_KEY]: hideCommercialToggle.checked });
});

openOptionsBtn.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

colorInput.addEventListener('input', () => {
  const settings = currentSettings();
  applyPreview(settings);
  saveSettings(settings);
});

sizeInput.addEventListener('input', () => {
  const settings = currentSettings();
  applyPreview(settings);
  saveSettings(settings);
});

markStyleInputs.forEach((el) => {
  el.addEventListener('change', () => {
    const settings = currentSettings();
    applyPreview(settings);
    saveSettings(settings);
  });
});

let resetArmed = false;
let resetTimer = null;

resetBtn.addEventListener('click', () => {
  if (!resetArmed) {
    resetArmed = true;
    resetBtn.textContent = 'לאשר איפוס?';
    resetTimer = setTimeout(() => {
      resetArmed = false;
      resetBtn.textContent = 'איפוס הכל';
    }, 3000);
    return;
  }

  clearTimeout(resetTimer);
  resetArmed = false;
  resetBtn.textContent = 'איפוס הכל';
  chrome.storage.local.set({ [VIEWED_KEY]: {} }, loadCount);
});

let unhideArmed = false;
let unhideTimer = null;

unhideBtn.addEventListener('click', () => {
  if (!unhideArmed) {
    unhideArmed = true;
    unhideBtn.textContent = 'לאשר?';
    unhideTimer = setTimeout(() => {
      unhideArmed = false;
      unhideBtn.textContent = 'הצג הכל מחדש';
    }, 3000);
    return;
  }

  clearTimeout(unhideTimer);
  unhideArmed = false;
  unhideBtn.textContent = 'הצג הכל מחדש';
  chrome.storage.local.set({ [HIDDEN_KEY]: {} }, loadHiddenCount);
});
