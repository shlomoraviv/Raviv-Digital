'use strict';

// מריץ את content.js *כמו שהוא* (בלי לשכפל את הלוגיקה) דרך מנגנון
// ה-__Y2H_TEST_HOOKS__ שכבר בנוי בקובץ עצמו בשביל בדיקות Node/CI.
// שם ה-shim למינימום הדרוש כדי שהקובץ ירוץ בלי לזרוק, בלי להריץ בפועל
// init()/scan() (readyState='loading' משאיר אותם רק "רשומים" ולא מופעלים).

let failures = 0;
let passed = 0;

function assertEqual(actual, expected, label) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) {
    passed += 1;
  } else {
    failures += 1;
    console.error(`✗ ${label}\n    ציפייה: ${JSON.stringify(expected)}\n    בפועל:  ${JSON.stringify(actual)}`);
  }
}

class FakeEventTarget {
  addEventListener() {}
  removeEventListener() {}
}

global.document = Object.assign(new FakeEventTarget(), {
  readyState: 'loading', // init() לא ירוץ בפועל - לא צריך לדמות את כל chrome.storage
  querySelectorAll: () => [],
});
global.location = { href: 'https://www.yad2.co.il/', pathname: '/', search: '' };
global.MutationObserver = class {
  observe() {}
  disconnect() {}
};
global.chrome = {
  storage: {
    local: { get: (_k, cb) => cb({}), set: () => {} },
    onChanged: { addListener: () => {} },
  },
  runtime: {},
};

let hooks = null;
global.__Y2H_TEST_HOOKS__ = (h) => {
  hooks = h;
};

require('../content.js');

if (!hooks) {
  console.error('✗ __Y2H_TEST_HOOKS__ מעולם לא נקרא - content.js לא נטען כמו שצריך');
  process.exit(1);
}

// עוזר: אלמנט <a> מזויף מספיק בשביל isCommercialCard/matchesBlacklist
function fakeAnchor({ href = '', innerAgencyHref = null, text = '' } = {}) {
  return {
    getAttribute: (name) => (name === 'href' ? href : null),
    querySelector: (sel) => (sel === 'a[href*="/agency/"]' && innerAgencyHref ? { href: innerAgencyHref } : null),
    textContent: text,
  };
}

console.log('--- idFromPath ---');
// תבנית רגילה (רכב) - ללא שינוי מהקיים
assertEqual(hooks.idFromPath('/vehicles/item/gludk5'), 'gludk5', 'idFromPath: רכב רגיל');
// תבנית נדל"ן עם קטע אזור - ללא שינוי מהקיים
assertEqual(hooks.idFromPath('/realestate/item/tel-aviv-area/ez5hhbbc'), 'ez5hhbbc', 'idFromPath: נדלן עם אזור');
// התבנית החדשה: פרויקט חדש (הבאג המדווח) - כתובות אמיתיות שנבדקו מול האתר
assertEqual(hooks.idFromPath('/yad1/project/18716'), '18716', 'idFromPath: פרויקט חדש (NEARO)');
assertEqual(hooks.idFromPath('/yad1/project/11285'), '11285', 'idFromPath: פרויקט חדש (שבירו ראש העין)');
// "project" בלי "yad1" לפניו לא אמור להיתפס (מניעת התנגשות עם נתיב לא קשור)
assertEqual(hooks.idFromPath('/some/other/project/12345'), null, 'idFromPath: project בלי yad1 - לא נתפס');
// מקרי קצה קיימים שאמורים להמשיך להיכשל כמו קודם
assertEqual(hooks.idFromPath('/vehicles/item/'), null, 'idFromPath: item בסוף הנתיב - null');
assertEqual(hooks.idFromPath('/vehicles/abc'), null, 'idFromPath: אין item/project בכלל - null');
assertEqual(hooks.idFromPath(''), null, 'idFromPath: נתיב ריק - null');
// באג שדווח: בתוך גלריית תמונות של מודעה, יד2 עשויה להוסיף עוד קטע
// *אחרי* המזהה (למשל מזהה/אינדקס תמונה) - צריך עדיין לתפוס נכון את מזהה
// המודעה (ולא את קטע התמונה) לפי מרחק קבוע מ-item/, לא "הקטע האחרון"
assertEqual(
  hooks.idFromPath('/realestate/item/tel-aviv-area/ez5hhbbc/photo-xyz1'),
  'ez5hhbbc',
  'idFromPath: נדלן עם קטע נוסף אחרי המזהה (תמונת גלריה) [הבאג שתוקן]'
);
assertEqual(
  hooks.idFromPath('/vehicles/item/gludk5/photo-xyz1'),
  'gludk5',
  'idFromPath: רכב עם קטע נוסף אחרי המזהה (תמונת גלריה) [הבאג שתוקן]'
);

console.log('--- idFromHref (כולל query string ודומיין מלא) ---');
assertEqual(
  hooks.idFromHref('https://www.yad2.co.il/yad1/project/15990?wat=3_0_0_0_51'),
  '15990',
  'idFromHref: פרויקט חדש עם query string מלא (NEARO TOWERS)'
);
assertEqual(hooks.idFromHref('/realestate/item/south/abcd12'), 'abcd12', 'idFromHref: קישור יחסי');

console.log('--- isCommercialCard ---');
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/yad1/project/8103?wat=x', text: 'שבירו פארק ראשון לציון' })),
  true,
  'isCommercialCard: פרויקט חדש מזוהה כמסחרי דרך ה-URL'
);
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/realestate/item/tel-aviv-area/ez5hhbbc', innerAgencyHref: '/realestate/agency/123/broker/456' })),
  true,
  'isCommercialCard: קישור לסוכנות פנימי (מבני, לא טקסט) - עדיין מסחרי'
);
// באג שדווח: "תיווך" כמילת מפתח תפסה בטעות גם מודעות רגילות - הן כי
// "תיווך" יכול להיות חלק משם החברה עצמה על הכרטיס (בלי שיש קישור אמיתי
// לעמוד סוכנות), והן כי מוכר פרטי לפעמים כותב "לא בתיווך" כדי *לשלול*
// שהוא מתווך. הוסרה מהרשימה - הסימן האמין הוא הקישור המבני בלבד.
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/realestate/item/tel-aviv-area/ez5hhbbc', text: 'דירה למכירה, תיווך א.פנגסי' })),
  false,
  'isCommercialCard: "תיווך" כחלק משם החברה בלי קישור סוכנות - לא מסחרית [הבאג שתוקן]'
);
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/realestate/item/tel-aviv-area/ez5hhbbc', text: 'דירה למכירה, פרטי, לא בתיווך' })),
  false,
  'isCommercialCard: "לא בתיווך" (שלילה) - לא מסחרית [הבאג שתוקן]'
);
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/realestate/item/tel-aviv-area/ez5hhbbc', text: 'דירת 3 חדרים, נוף לים, מיידי' })),
  false,
  'isCommercialCard: מודעה פרטית רגילה - לא מסחרית'
);
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/vehicles/item/gludk5', text: 'יונדאי איוניק 6 (60 חודשים) 1,967 ₪ לחודש' })),
  true,
  'isCommercialCard: תבנית מחיר חודשי (X חודשים) - סימן לרכב ליסינג/סוכנות'
);
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/vehicles/item/gludk5', text: 'יונדאי איוניק 6, יד 1, 2022' })),
  false,
  'isCommercialCard: מודעת רכב פרטית רגילה בלי מחיר חודשי - לא מסחרית'
);
assertEqual(
  hooks.isCommercialCard(fakeAnchor({ href: '/vehicles/item/gludk5', innerAgencyHref: '/vehicles/agency/8264067/cars' })),
  true,
  'isCommercialCard: קישור לעמוד סוכנות רכב (קיים כבר, רק לוודא שגם ברכב עובד)'
);

console.log('--- urlMatchesSearch (כולל תיקון מפתח כפול) ---');
assertEqual(
  hooks.urlMatchesSearch(
    'https://www.yad2.co.il/realestate/forsale?city=5000&rooms=3',
    'https://www.yad2.co.il/realestate/forsale?city=5000&rooms=3'
  ),
  true,
  'urlMatchesSearch: התאמה מדויקת רגילה (קיים מקודם)'
);
assertEqual(
  hooks.urlMatchesSearch(
    'https://www.yad2.co.il/realestate/forsale?city=5000&rooms=3&price=2000000',
    'https://www.yad2.co.il/realestate/forsale?city=5000&rooms=3'
  ),
  true,
  'urlMatchesSearch: לכתובת הנוכחית מותר להכיל עוד פרמטרים (קיים מקודם)'
);
assertEqual(
  hooks.urlMatchesSearch(
    'https://www.yad2.co.il/realestate/forsale?rooms=3&rooms=4&city=5000',
    'https://www.yad2.co.il/realestate/forsale?rooms=3&rooms=4&city=5000'
  ),
  true,
  'urlMatchesSearch: מפתח כפול (rooms מרובה-בחירה) - זו הכתובת המדויקת שנשמרה [הבאג שתוקן]'
);
assertEqual(
  hooks.urlMatchesSearch(
    'https://www.yad2.co.il/realestate/forsale?rooms=4&rooms=3&city=5000',
    'https://www.yad2.co.il/realestate/forsale?rooms=3&rooms=4&city=5000'
  ),
  true,
  'urlMatchesSearch: מפתח כפול, סדר שונה - עדיין התאמה [הבאג שתוקן]'
);
assertEqual(
  hooks.urlMatchesSearch(
    'https://www.yad2.co.il/realestate/forsale?rooms=3&city=5000',
    'https://www.yad2.co.il/realestate/forsale?rooms=3&rooms=4&city=5000'
  ),
  false,
  'urlMatchesSearch: חסר אחד מערכי המפתח הכפול - לא אמורה להיות התאמה'
);

console.log(`\n${passed} עברו, ${failures} נכשלו`);
process.exit(failures ? 1 : 0);
