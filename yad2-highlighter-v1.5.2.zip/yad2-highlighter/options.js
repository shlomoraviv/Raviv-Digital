const SEARCHES_KEY = 'y2h_searches';
const EMAIL_KEY = 'y2h_email';
const BG_CHECK_KEY = 'y2h_bg_check';
const BLACKLIST_KEY = 'y2h_blacklist';

const searchListEl = document.getElementById('searchList');
const addSearchForm = document.getElementById('addSearchForm');
const searchNameInput = document.getElementById('searchName');
const searchUrlInput = document.getElementById('searchUrl');
const searchIncludeInput = document.getElementById('searchIncludeKeywords');
const searchExcludeInput = document.getElementById('searchExcludeKeywords');
const searchFormError = document.getElementById('searchFormError');

const blacklistListEl = document.getElementById('blacklistList');
const addBlacklistForm = document.getElementById('addBlacklistForm');
const blacklistWordInput = document.getElementById('blacklistWord');

const toEmailInput = document.getElementById('toEmail');
const serviceIdInput = document.getElementById('serviceId');
const templateIdInput = document.getElementById('templateId');
const publicKeyInput = document.getElementById('publicKey');
const emailEnabledInput = document.getElementById('emailEnabled');
const sendTestBtn = document.getElementById('sendTestBtn');
const testStatus = document.getElementById('testStatus');

const bgCheckEnabledInput = document.getElementById('bgCheckEnabled');
const bgCheckIntervalInput = document.getElementById('bgCheckInterval');

let currentSearches = [];

function uid() {
  return 'srch_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function splitKeywords(value) {
  return value
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

function isYad2Url(value) {
  try {
    const u = new URL(value);
    return /(^|\.)yad2\.co\.il$/i.test(u.hostname);
  } catch {
    return false;
  }
}

function persistSearches() {
  chrome.storage.local.set({ [SEARCHES_KEY]: currentSearches });
}

function renderSearches(list) {
  searchListEl.innerHTML = '';

  if (!list.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';

    const title = document.createElement('p');
    title.className = 'empty-state__title';
    title.textContent = 'עדיין אין חיפושים שמורים';

    const subtitle = document.createElement('p');
    subtitle.className = 'empty-state__hint';
    subtitle.textContent = 'הוסיפו את הראשון בטופס שלמטה - כל מודעה חדשה שתתאים לו תיצור התראה.';

    empty.appendChild(title);
    empty.appendChild(subtitle);
    searchListEl.appendChild(empty);
    return;
  }

  list.forEach((s) => {
    const row = document.createElement('div');
    row.className = 'search-row';

    const info = document.createElement('div');
    info.className = 'search-row__info';

    const title = document.createElement('div');
    title.className = 'search-row__name';
    title.textContent = s.name;
    info.appendChild(title);

    const url = document.createElement('div');
    url.className = 'search-row__url';
    url.textContent = s.url;
    info.appendChild(url);

    if (s.includeKeywords && s.includeKeywords.length) {
      const inc = document.createElement('div');
      inc.className = 'search-row__meta';
      inc.textContent = 'כולל: ' + s.includeKeywords.join(', ');
      info.appendChild(inc);
    }
    if (s.excludeKeywords && s.excludeKeywords.length) {
      const exc = document.createElement('div');
      exc.className = 'search-row__meta';
      exc.textContent = 'לא כולל: ' + s.excludeKeywords.join(', ');
      info.appendChild(exc);
    }

    const actions = document.createElement('div');
    actions.className = 'search-row__actions';

    const toggle = document.createElement('input');
    toggle.type = 'checkbox';
    toggle.checked = s.enabled !== false;
    toggle.title = 'הפעלה/כיבוי של חיפוש זה';
    toggle.addEventListener('change', () => {
      s.enabled = toggle.checked;
      persistSearches();
    });

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn--text is-danger';
    del.textContent = 'מחיקה';
    del.addEventListener('click', () => {
      currentSearches = currentSearches.filter((x) => x.id !== s.id);
      persistSearches();
      renderSearches(currentSearches);
    });

    actions.appendChild(toggle);
    actions.appendChild(del);

    row.appendChild(info);
    row.appendChild(actions);
    searchListEl.appendChild(row);
  });
}

chrome.storage.local.get(SEARCHES_KEY, (res) => {
  currentSearches = res[SEARCHES_KEY] || [];
  renderSearches(currentSearches);
});

addSearchForm.addEventListener('submit', (e) => {
  e.preventDefault();
  searchFormError.hidden = true;

  const name = searchNameInput.value.trim();
  const url = searchUrlInput.value.trim();
  if (!name || !url) return;

  if (!isYad2Url(url)) {
    searchFormError.textContent = 'יש להזין כתובת מיד2.co.il תקינה.';
    searchFormError.hidden = false;
    return;
  }

  const entry = {
    id: uid(),
    name,
    url,
    enabled: true,
    includeKeywords: splitKeywords(searchIncludeInput.value),
    excludeKeywords: splitKeywords(searchExcludeInput.value),
  };

  currentSearches = [...currentSearches, entry];
  persistSearches();
  renderSearches(currentSearches);
  addSearchForm.reset();
});

// ---- רשימה שחורה ----

let currentBlacklist = [];

function persistBlacklist() {
  chrome.storage.local.set({ [BLACKLIST_KEY]: currentBlacklist });
}

function renderBlacklist(list) {
  blacklistListEl.innerHTML = '';

  if (!list.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';

    const title = document.createElement('p');
    title.className = 'empty-state__title';
    title.textContent = 'הרשימה השחורה ריקה';

    const subtitle = document.createElement('p');
    subtitle.className = 'empty-state__hint';
    subtitle.textContent = 'הוסיפו מילה או ביטוי כדי להתחיל להסתיר אוטומטית מודעות שמכילים אותם.';

    empty.appendChild(title);
    empty.appendChild(subtitle);
    blacklistListEl.appendChild(empty);
    return;
  }

  list.forEach((word) => {
    const row = document.createElement('div');
    row.className = 'search-row';

    const label = document.createElement('div');
    label.className = 'search-row__name';
    label.textContent = word;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn--text is-danger';
    del.textContent = 'מחיקה';
    del.addEventListener('click', () => {
      currentBlacklist = currentBlacklist.filter((w) => w !== word);
      persistBlacklist();
      renderBlacklist(currentBlacklist);
    });

    row.appendChild(label);
    row.appendChild(del);
    blacklistListEl.appendChild(row);
  });
}

chrome.storage.local.get(BLACKLIST_KEY, (res) => {
  currentBlacklist = res[BLACKLIST_KEY] || [];
  renderBlacklist(currentBlacklist);
});

addBlacklistForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const word = blacklistWordInput.value.trim();
  if (!word) return;

  if (currentBlacklist.some((w) => w.toLowerCase() === word.toLowerCase())) {
    addBlacklistForm.reset();
    return; // already in the list - nothing to do
  }

  currentBlacklist = [...currentBlacklist, word];
  persistBlacklist();
  renderBlacklist(currentBlacklist);
  addBlacklistForm.reset();
});

// ---- הגדרות מייל ----

chrome.storage.local.get(EMAIL_KEY, (res) => {
  const cfg = res[EMAIL_KEY] || {};
  toEmailInput.value = cfg.toEmail || '';
  serviceIdInput.value = cfg.serviceId || '';
  templateIdInput.value = cfg.templateId || '';
  publicKeyInput.value = cfg.publicKey || '';
  emailEnabledInput.checked = Boolean(cfg.enabled);
});

function currentEmailConfig() {
  return {
    toEmail: toEmailInput.value.trim(),
    serviceId: serviceIdInput.value.trim(),
    templateId: templateIdInput.value.trim(),
    publicKey: publicKeyInput.value.trim(),
    enabled: emailEnabledInput.checked,
  };
}

function persistEmailConfig() {
  chrome.storage.local.set({ [EMAIL_KEY]: currentEmailConfig() });
}

[toEmailInput, serviceIdInput, templateIdInput, publicKeyInput].forEach((el) => {
  el.addEventListener('change', persistEmailConfig);
});
emailEnabledInput.addEventListener('change', persistEmailConfig);

sendTestBtn.addEventListener('click', () => {
  testStatus.textContent = 'שולח...';
  testStatus.className = 'test-status';

  chrome.runtime.sendMessage(
    { type: 'y2h_send_test_email', overrideConfig: currentEmailConfig() },
    (result) => {
      if (chrome.runtime.lastError) {
        testStatus.textContent = 'שגיאה: לא ניתן לתקשר עם התוסף.';
        testStatus.classList.add('error');
        return;
      }
      if (result && result.ok) {
        testStatus.textContent = 'נשלח בהצלחה! בדקו את תיבת הדואר (וגם ספאם).';
        testStatus.classList.add('success');
      } else {
        const reason =
          result && result.error === 'missing_config'
            ? 'יש למלא Service ID, Template ID ו-Public Key.'
            : 'השליחה נכשלה. ודאו שהפרטים נכונים ונסו שוב.';
        testStatus.textContent = reason;
        testStatus.classList.add('error');
      }
    }
  );
});

// ---- בדיקה אוטומטית ברקע ----

chrome.storage.local.get(BG_CHECK_KEY, (res) => {
  const cfg = res[BG_CHECK_KEY] || { enabled: false, intervalMinutes: 30 };
  bgCheckEnabledInput.checked = Boolean(cfg.enabled);
  bgCheckIntervalInput.value = cfg.intervalMinutes || 30;
});

function persistBgCheck() {
  const intervalMinutes = Math.max(5, Number(bgCheckIntervalInput.value) || 30);
  bgCheckIntervalInput.value = intervalMinutes;
  chrome.storage.local.set({
    [BG_CHECK_KEY]: { enabled: bgCheckEnabledInput.checked, intervalMinutes },
  });
}

bgCheckEnabledInput.addEventListener('change', persistBgCheck);
bgCheckIntervalInput.addEventListener('change', persistBgCheck);
