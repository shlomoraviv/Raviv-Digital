/**
 * היילייטר ליד2 — content script
 * מסמן מודעות שכבר נצפו על גבי yad2.co.il (רכב, נדל"ן, מוצרים וכו'),
 * מאפשר לסמן מודעה כנצפתה או להסתיר אותה בלי לפתוח אותה בכלל, ומזהה מודעות
 * חדשות שתואמות לחיפושים שמורים (עבור התראות מייל/דסקטופ - ר' background.js).
 *
 * זיהוי מודעה: יד2 בונה קישורים לעמוד מודעה בתבנית ".../item/<...>/<מזהה>".
 * בקטגוריות מסוימות (רכב, מוצרים) המזהה מגיע מיד אחרי "item/", אבל בנדל"ן
 * יד2 מוסיפה קטע נוסף של אזור בין "item/" למזהה עצמו, למשל:
 *
 *   /vehicles/item/gludk5                     -> מזהה אמיתי: gludk5
 *   /realestate/item/tel-aviv-area/ez5hhbbc    -> מזהה אמיתי: ez5hhbbc
 *
 * המזהה נלקח לפי *מרחק קבוע* מ-"item/" (קטע אחד בד"כ, שני קטעים בנדל"ן -
 * הקטגוריה, שהיא הקטע *לפני* "item/", קובעת איזה מהם) - לא לפי "הקטע
 * האחרון בנתיב". זה חשוב כי בתוך גלריית תמונות של מודעה ספציפית יד2 לפעמים
 * מוסיפה עוד קטע *אחרי* המזהה (למשל מזהה/אינדקס של תמונה בודדת) - "הקטע
 * האחרון" היה תופס בטעות את מזהה התמונה במקום מזהה המודעה עצמה, מה שגרם
 * לכל תמונה בגלריה להיראות כמו "מודעה" נפרדת (עם ✓ משלה שגם נשאר קבוע,
 * כי checkCurrentPage מסמן את מה שהוא חושב שהוא "מזהה המודעה" הנוכחי בתור
 * נצפתה) במקום שהתוסף יזהה שכל התמונות שייכות לאותה מודעה בדיוק שכבר
 * נמצאים בה, ולא יצייר עליהן שום דבר.
 *
 * "פרויקט חדש" בנדל"ן (תוכן יזמים/פרסום, לא מודעה של משתמש פרטי) בנוי
 * אצל יד2 בתבנית *שונה לגמרי* - בלי "item" בנתיב בכלל:
 *
 *   /yad1/project/18716                        -> מזהה אמיתי: 18716
 *
 * בלי הכרה מפורשת בתבנית הזו (בנוסף ל-"item/"), כרטיס "פרויקט חדש" לא זוהה
 * כמודעה בכלל - לא ✓ ולא ✕ צוירו עליו, ממש כאילו התוסף לא "ראה" אותו. זו
 * הייתה הסיבה שהסתרה וסימון "נצפתה" לא עבדו על תוכן מסחרי/ממומן מהסוג הזה:
 * לא שהתוסף בחר לא להסתיר, אלא שהוא מעולם לא זיהה שיש שם מודעה להחליט
 * לגביה. אותה תבנית גם מזהה נכון ✓ אם נכנסים ישירות לעמוד פרויקט כזה.
 * דף סוכנות/יבואן/חברת ליסינג בנוי בתבנית ‎/<קטגוריה>/agency/<מזהה>/...‎ -
 * גם ברכב (‎/vehicles/agency/...‎) וגם בנדל"ן, לא רק בנדל"ן כמו שאולי נראה
 * בהתחלה.
 *
 * חוסן נוסף לנדל"ן: יד2 בנויה על Next.js עם פיד שמתמלא/מתעדכן בצד לקוח
 * (ולא תמיד ע"י הוספת/הסרת אלמנטים "רגילה"). כדי לא לפספס עמודים כאלה,
 * הסריקה כאן:
 *   1. יורדת גם לתוך Shadow DOM פתוח (רכיבי web components, למשל אזור עם
 *      מפה משולבת), ולא רק ל-DOM ה"רגיל".
 *   2. עוקבת גם אחרי שינויי attribute על href (לא רק childList) - כדי
 *      לתפוס מקרה שבו רשימה "ממחזרת" אלמנטים קיימים במקום ליצור חדשים.
 *   3. מריצה עוד סריקה ביטחון כמה שניות אחרי הטעינה הראשונית, למקרה שתוכן
 *      מסוים נטען בשלב נפרד.
 * כל אלמנט מזוהה נושא את המזהה העדכני שלו על ה-DOM עצמו (data-y2h-id),
 * כך שגם אם אלמנט קיים "מתמחזר" למודעה אחרת, כל הלוגיקה (סימון, הסתרה,
 * לחיצה) תמיד קוראת את המזהה העדכני במקום להסתמך על ערך ישן שנשמר בזיכרון.
 */
(() => {
  'use strict';

  const VIEWED_KEY = 'y2h_viewed';
  const SETTINGS_KEY = 'y2h_settings';
  const HIDDEN_KEY = 'y2h_hidden';
  const HIDE_COMMERCIAL_KEY = 'y2h_hide_commercial';
  const SEARCHES_KEY = 'y2h_searches';
  const BLACKLIST_KEY = 'y2h_blacklist';

  // markStyle: 'full' צובע את כל הכרטיס (ברירת המחדל, כמו עד כה),
  // 'checkOnly' משאיר רק את תג ה-✓ הקבוע בפינה בלי לצבוע את שאר הכרטיס.
  const DEFAULTS = { color: '#ffd400', size: 6, markStyle: 'full' };

  // מזהה תקין ביד2 הוא מחרוזת אותיות/ספרות (ללא מקפים), לרוב 6-8 תווים.
  // דורשים לפחות 4 תווים כדי לא לתפוס בטעות קטעי נתיב קצרים/לא צפויים.
  const VALID_ID_RE = /^[a-zA-Z0-9]{4,}$/;

  // מילות מפתח המעידות על מודעה שפורסמה ע"י גורם עסקי, לצורך ההסתרה
  // האוטומטית של מודעות מסחריות. בכוונה *לא* נעשה שימוש במילה "מסחרי"/
  // "עסקי" לבד, כי בנדל"ן "נכס מסחרי" הוא סוג נכס (יכול להיות גם מודעה
  // פרטית) ולא סימן לכך שהמפרסם הוא גוף עסקי.
  //
  // "תיווך"/"מתווך"/"בתיווך" וכו' *הוסרו* מהרשימה (היו כאן עד גרסה 1.5.1):
  // התברר שהם תופסים בטעות גם מודעות רגילות - הן כי "תיווך" מופיע כחלק
  // משם החברה/המתווך עצמו על הכרטיס (למשל "תיווך א.פנגסי"), שזה לא באמת
  // "פרסום ממומן", והן כי מוכר פרטי כותב לפעמים במפורש "לא בתיווך" כדי
  // *לשלול* שהוא מתווך - וניחוש טקסט נאיבי תופס את המילה גם שם, בלי להבין
  // שלילה. הסימן האמין להיות "פורסם ע"י סוכנות" הוא המבני
  // (a[href*="/agency/"] למטה) - קישור אמיתי לעמוד סוכנות, לא רק אזכור
  // מילולי של המושג איפשהו בכרטיס. אפשר להוסיף כאן מילים נוספות, אבל כדאי
  // קודם לוודא שהן לא עלולות להופיע כחלק משם עסק או במשפט שלילה.
  const COMMERCIAL_TEXT_MARKERS = [
    'סוכנות רכב',
    'יבואן רשמי',
    'חברת ליסינג',
    'ליסינג תפעולי',
  ];

  let viewed = new Set();
  let hidden = new Set();
  let hideCommercial = false;
  let blacklist = [];
  let searches = [];
  let settings = { ...DEFAULTS };
  let scanTimer = null;
  let mutationObserver = null;
  const reportedThisLoad = new Set();
  const knownRoots = new Set();
  let lastLoggedCount = -1;

  function idFromPath(pathname) {
    if (!pathname) return null;
    const segments = pathname.split('/').filter(Boolean);

    const itemIdx = segments.findIndex((seg) => seg.toLowerCase() === 'item');
    if (itemIdx !== -1) {
      // הקטע *לפני* item/ הוא הקטגוריה (vehicles/realestate/...) - היא
      // קובעת כמה קטעים יש בין item/ למזהה עצמו: בנדל"ן יש קטע אזור נוסף
      // (offset 2), בכל השאר המזהה מגיע מיד (offset 1). לוקחים קטע לפי
      // *מרחק קבוע* מ-item/ ולא "הקטע האחרון בנתיב", כדי לא להתבלבל אם
      // מגיע עוד קטע *אחרי* המזהה (כמו מזהה תמונה בתוך גלריה - ר' תיעוד
      // בראש הקובץ).
      const category = itemIdx > 0 ? segments[itemIdx - 1].toLowerCase() : '';
      const offset = category === 'realestate' ? 2 : 1;
      const candidate = segments[itemIdx + offset];
      return candidate && VALID_ID_RE.test(candidate) ? candidate.toLowerCase() : null;
    }

    // "project" לבד עלול להתנגש עם נתיבים אחרים באתר שלא קשורים למודעה
    // ספציפית - דורשים שיופיע תחת "yad1" (מדור פרויקטים/יזמים), בדיוק
    // כפי שבנוי בפועל ביד2 (ר' הערת התיעוד למעלה).
    const projectIdx = segments.findIndex(
      (seg, i) => seg.toLowerCase() === 'project' && i > 0 && segments[i - 1].toLowerCase() === 'yad1'
    );
    if (projectIdx !== -1) {
      const candidate = segments[projectIdx + 1];
      return candidate && VALID_ID_RE.test(candidate) ? candidate.toLowerCase() : null;
    }

    return null;
  }

  function idFromHref(href) {
    if (!href) return null;
    try {
      return idFromPath(new URL(href, location.href).pathname);
    } catch {
      return null;
    }
  }

  // משקף את markStyle הנוכחי כמחלקה על <html>, כדי שה-CSS (content.css)
  // יוכל לדעת אם תג ה-✓ צריך להישאר גלוי תמיד (מצב "רק ✓ בפינה", שבו הוא
  // הסימון היחיד) או רק בריחוף (מצב "צביעת הכרטיס", שבו יש כבר צביעה
  // שמשמשת כסימון הקבוע - תג צמוד-לצמיתות רק מפריע שם, למשל מכסה מחיר).
  function syncModeClass() {
    document.documentElement.classList.toggle('y2h-mode-check-only', settings.markStyle === 'checkOnly');
  }

  function applyStyle(el) {
    if (settings.markStyle === 'checkOnly') {
      // במצב הזה מסתפקים בתג ה-✓ הקבוע (מטופל בנפרד ב-processAnchor,
      // ולא תלוי בפונקציה הזו) ולא צובעים את שאר הכרטיס. מוודאים גם
      // שמסירים צביעה קודמת אם המצב הוחלף בזמן שהמודעה כבר הייתה צבועה.
      el.classList.remove('y2h-mark');
      el.style.removeProperty('--y2h-color');
      el.style.removeProperty('--y2h-size');
      return;
    }
    el.classList.add('y2h-mark');
    el.style.setProperty('--y2h-color', settings.color);
    el.style.setProperty('--y2h-size', settings.size + 'px');
  }

  function clearStyle(el) {
    el.classList.remove('y2h-mark');
    el.style.removeProperty('--y2h-color');
    el.style.removeProperty('--y2h-size');
  }

  function applyHiddenStyle(el) {
    el.classList.add('y2h-hidden');
  }

  function clearHiddenStyle(el) {
    el.classList.remove('y2h-hidden');
  }

  function markViewed(id) {
    if (!id || viewed.has(id)) return;
    viewed.add(id);
    chrome.storage.local.get(VIEWED_KEY, (res) => {
      const map = res[VIEWED_KEY] || {};
      if (map[id]) return;
      map[id] = Date.now();
      chrome.storage.local.set({ [VIEWED_KEY]: map });
    });
  }

  function hideAd(id) {
    if (!id || hidden.has(id)) return;
    hidden.add(id);
    chrome.storage.local.get(HIDDEN_KEY, (res) => {
      const map = res[HIDDEN_KEY] || {};
      if (map[id]) return;
      map[id] = Date.now();
      chrome.storage.local.set({ [HIDDEN_KEY]: map });
    });
  }

  // תבנית "X ₪ (NN חודשים)" - מחיר תשלום חודשי לאורך תקופת מימון/ליסינג.
  // מוכר פרטי כמעט אף פעם לא מפרסם ככה (הוא מוכר במחיר אחד וסופי) - זו
  // דרך שיווק אופיינית לסוכנויות רכב חדש/חברות ליסינג. הביטחון כאן נמוך
  // יותר מהסימנים המבניים למעלה (מבוסס על טקסט, לא על מבנה קישור), אבל
  // התבנית הזו ספציפית מספיק (מספר + "חודשים" בתוך סוגריים) שהסיכוי
  // שמודעה פרטית רגילה תכיל אותה בטעות נמוך.
  const MONTHLY_PAYMENT_RE = /\(\s*\d+\s*חודשים\s*\)/;

  function isCommercialCard(a) {
    // סימן מבני אמין ב-100% (לא ניחוש טקסט): "פרויקט חדש" בנדל"ן מקבל
    // מיד2 קישור בתבנית /yad1/project/<מזהה> - ר' idFromPath/התיעוד למעלה.
    // זה בהגדרה תוכן יזמים/פרסום, לא מודעה של אדם פרטי.
    if (/\/yad1\/project\//i.test(a.getAttribute('href') || '')) return true;

    // סימן ראשי נוסף, אמין יחסית: קישור בתוך כרטיס המודעה לעמוד סוכנות/משרד
    // תיווך (יד2 בונה עמודים כאלה בתבנית ‎/.../agency/<מזהה>/...‎ - גם ברכב,
    // ‎/vehicles/agency/...‎, לא רק בנדל"ן).
    if (a.querySelector('a[href*="/agency/"]')) return true;

    // סימן משני: מילות מפתח גלויות בטקסט הכרטיס, וכן תבנית מחיר חודשי
    // (ר' MONTHLY_PAYMENT_RE למעלה). משתמשים ב-textContent (ולא innerText)
    // כי הבדיקה הזו רצה על כל כרטיס בכל סריקה, ו-innerText "יקר" יותר
    // לביצועים כי הוא תלוי בפריסה (layout) בפועל של העמוד.
    const text = a.textContent || '';
    if (MONTHLY_PAYMENT_RE.test(text)) return true;
    return COMMERCIAL_TEXT_MARKERS.some((marker) => text.includes(marker));
  }

  function matchesBlacklist(a) {
    if (!blacklist.length) return false;
    const text = (a.textContent || '').toLowerCase();
    return blacklist.some((word) => text.includes(String(word).toLowerCase()));
  }

  /**
   * שני כפתורים קטנים שצפים בפינת המודעה: "✓" מסמן כנצפתה בלי לפתוח (וגם
   * משמש כתג-סטטוס קבוע ברגע שהמודעה כבר סומנה - כדי שהסימון ייראה גם
   * במודעות עם תמונה גדולה שמכסה כמעט את כל הכרטיס), ו-"✕" מסתיר אותה.
   * מוצמדים בפינה התחתונה (ולא העליונה) כי בפינה העליונה נוטים לשבת
   * לוגו/תג "מומלץ" של סוכנויות, שעלול לכסות כפתור שיושב שם.
   */
  function ensureActionButtons(a) {
    if (a.dataset.y2hActionsBound) return;
    a.dataset.y2hActionsBound = '1';

    const cluster = document.createElement('div');
    cluster.className = 'y2h-actions';

    const seenBtn = document.createElement('div');
    seenBtn.className = 'y2h-seen-btn';
    seenBtn.setAttribute('role', 'button');
    seenBtn.setAttribute('tabindex', '0');
    seenBtn.setAttribute('aria-label', 'סמן כנצפתה');
    seenBtn.title = 'סמן כנצפתה (בלי לפתוח)';
    seenBtn.textContent = '✓';

    const hideBtn = document.createElement('div');
    hideBtn.className = 'y2h-hide-btn';
    hideBtn.setAttribute('role', 'button');
    hideBtn.setAttribute('tabindex', '0');
    hideBtn.setAttribute('aria-label', 'הסתר מודעה זו');
    hideBtn.title = 'הסתר מודעה זו';
    hideBtn.textContent = '✕';

    cluster.appendChild(seenBtn);
    cluster.appendChild(hideBtn);
    a.appendChild(cluster);
  }

  function urlMatchesSearch(currentHref, savedUrl) {
    try {
      const cur = new URL(currentHref);
      const saved = new URL(savedUrl);
      if (cur.origin !== saved.origin || cur.pathname !== saved.pathname) return false;
      const curParams = new URLSearchParams(cur.search);
      const savedParams = new URLSearchParams(saved.search);
      const checkedKeys = new Set();
      for (const key of savedParams.keys()) {
        if (checkedKeys.has(key)) continue; // כבר נבדק (המפתח חוזר בפרמטרים)
        checkedKeys.add(key);
        // getAll (ולא get) כי בפילטר מרובה-בחירה יד2 יכולה לחזור על אותו
        // מפתח כמה פעמים (למשל ‎?rooms=3&rooms=4‎). get() היה בודק תמיד רק
        // את המופע הראשון - כך שחיפוש שמור עם מפתח כפול לא היה תואם אף
        // פעם, גם מול הכתובת המדויקת שממנה הוא נשמר, וההתראות עליו היו
        // נכשלות בשקט.
        const savedValues = savedParams.getAll(key);
        const curValues = curParams.getAll(key);
        if (!savedValues.every((v) => curValues.includes(v))) return false;
      }
      return true;
    } catch {
      return false;
    }
  }

  function passesKeywordFilters(text, search) {
    const lower = text.toLowerCase();
    const include = search.includeKeywords || [];
    const exclude = search.excludeKeywords || [];
    if (include.length && !include.some((k) => lower.includes(String(k).toLowerCase()))) {
      return false;
    }
    if (exclude.length && exclude.some((k) => lower.includes(String(k).toLowerCase()))) {
      return false;
    }
    return true;
  }

  function activeMatchingSearches() {
    if (!searches.length) return [];
    return searches.filter((s) => s.url && s.enabled !== false && urlMatchesSearch(location.href, s.url));
  }

  function maybeNotifyIfMatches(a, id) {
    if (!searches.length) return;
    const matches = activeMatchingSearches();
    if (!matches.length) return;

    const text = (a.innerText || a.textContent || '').replace(/\s+/g, ' ').trim();

    matches.forEach((s) => {
      const dedupKey = `${s.id}:${id}`;
      if (reportedThisLoad.has(dedupKey)) return;
      if (!passesKeywordFilters(text, s)) return;

      reportedThisLoad.add(dedupKey);

      let link = '';
      try {
        link = new URL(a.getAttribute('href'), location.href).href;
      } catch {
        link = location.href;
      }
      const imgEl = a.querySelector('img');
      const image = imgEl ? imgEl.currentSrc || imgEl.src || '' : '';

      chrome.runtime.sendMessage({
        type: 'y2h_new_match',
        dedupKey,
        searchName: s.name || '',
        ad: { id, title: text.slice(0, 200), link, image },
      });
    });
  }

  /**
   * מגלה את כל ה-"שורשים" שיש לחפש בהם קישורי מודעה: המסמך עצמו, ועוד
   * כל Shadow root פתוח שנמצא בתוכו (רקורסיבית). כל שורש חדש שמתגלה גם
   * מקבל מעקב MutationObserver משלו - observer יחיד יכול לעקוב אחרי כמה
   * "שורשים" שונים בו-זמנית.
   */
  function discoverRoots(root) {
    if (!knownRoots.has(root)) {
      knownRoots.add(root);
      if (mutationObserver) {
        mutationObserver.observe(root, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['href'],
        });
      }
    }
    // תמיד ממשיכים לרדת פנימה, גם אם ה-root הזה כבר מוכר - כי ייתכן
    // שנוסף לו shadow root מקונן חדש מאז הפעם הקודמת שנבדק.
    root.querySelectorAll('*').forEach((el) => {
      if (el.shadowRoot) discoverRoots(el.shadowRoot);
    });
  }

  function undecorate(a) {
    clearStyle(a);
    clearHiddenStyle(a);
    a.classList.remove('y2h-item-link');
    const actions = a.querySelector('.y2h-actions');
    if (actions) actions.remove();
    delete a.dataset.y2hId;
    delete a.dataset.y2hActionsBound;
    delete a.dataset.y2hCommercial;
    delete a.dataset.y2hBlacklisted;
    // בכוונה *לא* מוחקים dataset.y2hBound: מאזין הלחיצה כבר קורא את המזהה
    // מה-dataset בזמן אמת ונותן no-op אם הוא ריק, כך שאין טעם/צורך לצרף
    // מאזין נוסף בעתיד אם האלמנט הזה יהפוך שוב לקנוני.
  }

  function processAnchor(a, id) {
    a.dataset.y2hId = id;
    a.classList.add('y2h-item-link');

    if (!a.dataset.y2hBound) {
      a.dataset.y2hBound = '1';
      // capture:true כדי לתפוס את הלחיצה גם אם הראוטר של האתר עוצר את
      // ההפצה (stopPropagation) לצורך ניווט בצד הלקוח. קוראים את המזהה
      // מה-dataset בזמן הלחיצה (לא ערך "קפוא" מרגע הבינדינג), כדי לא
      // להתבלבל אם האלמנט הזה עצמו מוחזר בעתיד למודעה אחרת.
      a.addEventListener('click', () => markViewed(a.dataset.y2hId), { capture: true });
    }

    ensureActionButtons(a);

    const isViewed = viewed.has(id);
    if (isViewed) {
      applyStyle(a);
    } else {
      clearStyle(a);
    }

    const seenBtn = a.querySelector('.y2h-seen-btn');
    if (seenBtn) seenBtn.classList.toggle('is-active', isViewed);

    // חושפים את תוצאות הזיהוי כ-attributes גלויים (data-y2h-*), גם כשהמתגים
    // כבויים - כדי שאפשר יהיה לבדוק ב-DevTools (ימני->בדוק) על מודעה
    // ספציפית למה היא הוסתרה או לא הוסתרה, בלי ניחושים.
    const isCommercial = isCommercialCard(a);
    a.dataset.y2hCommercial = isCommercial ? '1' : '0';

    const isBlacklisted = matchesBlacklist(a);
    a.dataset.y2hBlacklisted = isBlacklisted ? '1' : '0';

    const shouldHide = hidden.has(id) || (hideCommercial && isCommercial) || isBlacklisted;
    if (shouldHide) {
      applyHiddenStyle(a);
    } else {
      clearHiddenStyle(a);
    }

    maybeNotifyIfMatches(a, id);
    return true;
  }

  function scan() {
    discoverRoots(document);

    // מזהה העמוד הנוכחי (אם נמצאים כרגע בתוך עמוד מודעה עצמו). קישורים
    // שחוזרים לאותה מודעה בדיוק (כמו שקופיות בגלריית תמונות שכולן מצביעות
    // בחזרה לעמוד המודעה שבו כבר נמצאים) לא צריכים כפתורי פעולה משלהם -
    // ה"נצפתה" כבר טופל ע"י checkCurrentPage(), וכפתור על כל שקופית רק
    // מפזר תגים מיותרים על פני התמונה במסך מלא.
    const currentPageId = idFromPath(location.pathname);
    const seenThisScan = new Set();
    let matched = 0;

    knownRoots.forEach((root) => {
      root.querySelectorAll('a[href]').forEach((a) => {
        const id = idFromHref(a.getAttribute('href'));

        if (!id) {
          if (a.dataset.y2hId) undecorate(a);
          return;
        }

        const isSelfLink = Boolean(currentPageId) && id === currentPageId;
        // אם כמה קישורים באותה סריקה מצביעים לאותה מודעה בדיוק (שוב, בעיקר
        // תופעה של גלריות/קרוסלות עם כמה שקופיות שכולן חוזרות לאותו href),
        // רק הראשון בסדר ה-DOM מקבל כפתורים - לא מכפילים אותם על כל שקופית.
        const isDuplicate = seenThisScan.has(id);

        if (isSelfLink || isDuplicate) {
          if (a.dataset.y2hId) undecorate(a);
          return;
        }

        seenThisScan.add(id);
        if (processAnchor(a, id)) matched += 1;
      });
    });

    // לוג אבחון קליל: נכתב רק כשהמספר *משתנה*, כדי לא להציף את הקונסולה.
    // אם 0 מודעות מזוהות בעמוד תוצאות אמיתי, זה הסימן הראשון לבדוק בקונסולה.
    if (matched !== lastLoggedCount) {
      lastLoggedCount = matched;
      console.debug('[היילייטר ליד2] מודעות מזוהות בעמוד:', matched, '| שורשי DOM שנסרקים:', knownRoots.size);
    }
  }

  function scheduleScan(delay = 250) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, delay);
  }

  function checkCurrentPage() {
    // אם נכנסים ישירות לעמוד מודעה (קישור משותף, "חזור", טאב חדש וכו')
    const id = idFromPath(location.pathname);
    if (id) markViewed(id);
  }

  function watchSpaNavigation() {
    // יד2 היא אפליקציית SPA - מעברי עמוד לא תמיד גוררים טעינה מלאה
    let last = location.href;
    setInterval(() => {
      if (location.href !== last) {
        last = location.href;
        checkCurrentPage();
        scheduleScan(400);
      }
    }, 600);
  }

  // מיירט לחיצות/מקלדת על כפתורי הפעולה *לפני* שהאירוע מגיע לקישור המודעה
  // עצמו: capture:true על document רץ לפני capture:true על ה-<a> (כי
  // document קודם ל-<a> בשרשרת ה-capture כלפי מטה). כך לחיצה על כפתור לא
  // גם מנווטת לעמוד המודעה וגם לא מסמנת אותה כ"נצפתה" בטעות דרך הקישור
  // עצמו. המזהה תמיד נקרא מה-<a> הקרוב (data-y2h-id) ברגע הלחיצה, לא
  // מערך שנשמר מראש - כך זה תקין גם אם האלמנט מוחזר בין מודעות שונות.
  function handleActionInteraction(e) {
    const target = e.target && e.target.nodeType === 1 ? e.target : null;
    if (!target || !target.closest) return;

    const hideBtn = target.closest('.y2h-hide-btn');
    const seenBtn = !hideBtn ? target.closest('.y2h-seen-btn') : null;
    if (!hideBtn && !seenBtn) return;

    e.preventDefault();
    e.stopPropagation();

    const anchor = (hideBtn || seenBtn).closest('.y2h-item-link');
    const id = anchor && anchor.dataset.y2hId;
    if (!id) return;

    if (hideBtn) {
      hideAd(id);
    } else {
      markViewed(id);
      scheduleScan(0);
    }
  }

  document.addEventListener('click', handleActionInteraction, { capture: true });
  document.addEventListener(
    'keydown',
    (e) => {
      if (e.key === 'Enter' || e.key === ' ') handleActionInteraction(e);
    },
    { capture: true }
  );

  function init() {
    mutationObserver = new MutationObserver(() => scheduleScan());

    chrome.storage.local.get(
      [VIEWED_KEY, SETTINGS_KEY, HIDDEN_KEY, HIDE_COMMERCIAL_KEY, SEARCHES_KEY, BLACKLIST_KEY],
      (res) => {
        viewed = new Set(Object.keys(res[VIEWED_KEY] || {}));
        settings = { ...DEFAULTS, ...(res[SETTINGS_KEY] || {}) };
        syncModeClass();
        hidden = new Set(Object.keys(res[HIDDEN_KEY] || {}));
        hideCommercial = Boolean(res[HIDE_COMMERCIAL_KEY]);
        searches = res[SEARCHES_KEY] || [];
        blacklist = res[BLACKLIST_KEY] || [];

        checkCurrentPage();
        scan();

        // רשת ביטחון: בחלק מהעמודים (בעיקר תוצאות נדל"ן) חלק מהתוכן מסיים
        // להיטען רגע אחרי הציור הראשוני, בלי שתמיד ניתפוס את זה במוטציה.
        // סורקים שוב פעמיים נוספות ליתר ביטחון.
        setTimeout(scan, 1200);
        setTimeout(scan, 3000);

        watchSpaNavigation();
      }
    );
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;

    if (changes[VIEWED_KEY]) {
      viewed = new Set(Object.keys(changes[VIEWED_KEY].newValue || {}));
      document.querySelectorAll('.y2h-mark').forEach(clearStyle);
      scan();
    }

    if (changes[SETTINGS_KEY]) {
      settings = { ...DEFAULTS, ...(changes[SETTINGS_KEY].newValue || {}) };
      syncModeClass();
      // scan() (ולא רק עדכון --y2h-color/--y2h-size כמו קודם) כי markStyle
      // יכול לשנות גם *האם* .y2h-mark בכלל אמור להיות על האלמנט, לא רק
      // את הצבע/העובי שלו - וסריקה מלאה מיישמת מחדש את שניהם נכון, על כל
      // המודעות המוכרות כרגע (כולל בתוך Shadow DOM).
      scan();
    }

    if (changes[HIDDEN_KEY]) {
      hidden = new Set(Object.keys(changes[HIDDEN_KEY].newValue || {}));
      scan();
    }

    if (changes[HIDE_COMMERCIAL_KEY]) {
      hideCommercial = Boolean(changes[HIDE_COMMERCIAL_KEY].newValue);
      scan();
    }

    if (changes[BLACKLIST_KEY]) {
      blacklist = changes[BLACKLIST_KEY].newValue || [];
      scan();
    }

    if (changes[SEARCHES_KEY]) {
      searches = changes[SEARCHES_KEY].newValue || [];
    }
  });

  // חושף פונקציות טהורות לבדיקות אוטומטיות (Node/CI) בלבד. בדפדפן האמיתי
  // globalThis.__Y2H_TEST_HOOKS__ תמיד undefined, ולכן השורה הבאה לא עושה שם
  // כלום ולא משפיעה על ההתנהגות בפועל.
  if (typeof globalThis !== 'undefined' && typeof globalThis.__Y2H_TEST_HOOKS__ === 'function') {
    globalThis.__Y2H_TEST_HOOKS__({
      idFromPath,
      idFromHref,
      urlMatchesSearch,
      passesKeywordFilters,
      isCommercialCard,
      matchesBlacklist,
      scan,
      markViewed,
      hideAd,
      getState: () => ({ viewed, hidden, hideCommercial, blacklist, searches, settings, knownRoots }),
      setState: (patch) => {
        if ('viewed' in patch) viewed = patch.viewed;
        if ('hidden' in patch) hidden = patch.hidden;
        if ('hideCommercial' in patch) hideCommercial = patch.hideCommercial;
        if ('blacklist' in patch) blacklist = patch.blacklist;
        if ('searches' in patch) searches = patch.searches;
        if ('settings' in patch) settings = patch.settings;
      },
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
