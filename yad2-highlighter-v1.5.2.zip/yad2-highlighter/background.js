/**
 * היילייטר ליד2 — Service Worker (רקע)
 * אחראי על:
 *  1. מניעת שליחה כפולה של התראה על אותה מודעה (dedup לפי חיפוש+מזהה מודעה).
 *  2. שליחת מייל בפועל דרך EmailJS (שירות חיצוני חינמי לשליחת מייל מהדפדפן,
 *     ללא צורך בשרת) + התראת דסקטופ מיידית בכל מקרה.
 *  3. בדיקה תקופתית ברקע (אופציונלית, כבויה כברירת מחדל): פותחת וסוגרת טאב
 *     סמוי לכל חיפוש שמור, כדי שהתוסף יבדוק מודעות חדשות גם כשלא גולשים
 *     ביד2 באותו רגע.
 */

const NOTIFIED_KEY = 'y2h_notified';
const EMAIL_KEY = 'y2h_email';
const BG_CHECK_KEY = 'y2h_bg_check';
const SEARCHES_KEY = 'y2h_searches';
const ALARM_NAME = 'y2h_bg_check_alarm';

const pendingNotificationLinks = new Map();

function getLocal(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function setLocal(obj) {
  return new Promise((resolve) => chrome.storage.local.set(obj, resolve));
}

async function alreadyNotified(dedupKey) {
  const res = await getLocal(NOTIFIED_KEY);
  const map = res[NOTIFIED_KEY] || {};
  return Boolean(map[dedupKey]);
}

async function markNotified(dedupKey) {
  const res = await getLocal(NOTIFIED_KEY);
  const map = res[NOTIFIED_KEY] || {};
  map[dedupKey] = Date.now();
  await setLocal({ [NOTIFIED_KEY]: map });
}

function escapeForEmail(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function buildTemplateParams({ searchName, ad, toEmail }) {
  return {
    to_email: toEmail || '',
    search_name: escapeForEmail(searchName),
    ad_title: escapeForEmail(ad.title) || 'מודעה חדשה ביד2',
    ad_link: ad.link || '',
    ad_image: ad.image || '',
  };
}

async function sendEmail(emailConfig, templateParams) {
  const serviceId = emailConfig && emailConfig.serviceId;
  const templateId = emailConfig && emailConfig.templateId;
  const publicKey = emailConfig && emailConfig.publicKey;

  if (!serviceId || !templateId || !publicKey) {
    return { ok: false, error: 'missing_config' };
  }

  try {
    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: serviceId,
        template_id: templateId,
        user_id: publicKey,
        template_params: templateParams,
      }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      return { ok: false, error: `http_${res.status}`, detail };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: 'network', detail: String(err && err.message ? err.message : err) };
  }
}

function notifyDesktop(dedupKey, ad, searchName) {
  const notifId = `y2h_${dedupKey}`;
  chrome.notifications.create(notifId, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: `מודעה חדשה: ${searchName || 'חיפוש שמור'}`,
    message: (ad.title || 'נמצאה מודעה חדשה תואמת').slice(0, 200),
    priority: 1,
  });
  if (ad.link) pendingNotificationLinks.set(notifId, ad.link);
}

chrome.notifications.onClicked.addListener((notifId) => {
  const link = pendingNotificationLinks.get(notifId);
  if (link) chrome.tabs.create({ url: link });
});

async function handleNewMatch(msg) {
  const { dedupKey, searchName, ad } = msg;
  if (!dedupKey || !ad) return;
  if (await alreadyNotified(dedupKey)) return;
  await markNotified(dedupKey);

  notifyDesktop(dedupKey, ad, searchName);

  const res = await getLocal(EMAIL_KEY);
  const emailConfig = res[EMAIL_KEY] || {};
  if (emailConfig.enabled && emailConfig.toEmail) {
    const params = buildTemplateParams({ searchName, ad, toEmail: emailConfig.toEmail });
    await sendEmail(emailConfig, params);
    // כשל בשליחת המייל אינו קריטי: המשתמש כבר קיבל התראת דסקטופ בכל מקרה.
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;

  if (msg.type === 'y2h_new_match') {
    handleNewMatch(msg);
    return false;
  }

  if (msg.type === 'y2h_send_test_email') {
    (async () => {
      const res = await getLocal(EMAIL_KEY);
      const emailConfig = { ...(res[EMAIL_KEY] || {}), ...(msg.overrideConfig || {}) };
      const params = buildTemplateParams({
        searchName: 'בדיקה',
        ad: { title: 'זו הודעת בדיקה מהתוסף היילייטר ליד2', link: 'https://www.yad2.co.il' },
        toEmail: emailConfig.toEmail,
      });
      const result = await sendEmail(emailConfig, params);
      sendResponse(result);
    })();
    return true; // משאיר את ערוץ ההודעות פתוח לתשובה אסינכרונית
  }

  return false;
});

// ---- בדיקה תקופתית ברקע (אופציונלי, כבוי כברירת מחדל) ----

async function rebuildAlarm() {
  const res = await getLocal(BG_CHECK_KEY);
  const cfg = res[BG_CHECK_KEY] || {};
  await chrome.alarms.clear(ALARM_NAME);
  if (cfg.enabled && Number(cfg.intervalMinutes) >= 5) {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: Number(cfg.intervalMinutes) });
  }
}

chrome.runtime.onInstalled.addListener(rebuildAlarm);
chrome.runtime.onStartup.addListener(rebuildAlarm);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[BG_CHECK_KEY]) rebuildAlarm();
});

function checkOneSearchInBackgroundTab(search) {
  return new Promise((resolve) => {
    let settled = false;
    let tabId = null;

    function finish() {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      if (tabId != null) {
        // המתנה קצרה נוספת אחרי טעינת הדף, כדי לתת ל-content script זמן
        // לסרוק את הדף ולשלוח הודעות y2h_new_match לפני שסוגרים את הטאב.
        setTimeout(() => {
          chrome.tabs.remove(tabId).catch(() => {});
          resolve();
        }, 4000);
      } else {
        resolve();
      }
    }

    function onUpdated(id, info) {
      if (id === tabId && info.status === 'complete') finish();
    }

    chrome.tabs.onUpdated.addListener(onUpdated);

    chrome.tabs.create({ url: search.url, active: false }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        finish();
        return;
      }
      tabId = tab.id;
      setTimeout(finish, 20000); // רשת ביטחון אם הטאב לעולם לא מסיים לטעון
    });
  });
}

async function runBackgroundCheck() {
  const res = await getLocal(SEARCHES_KEY);
  const list = (res[SEARCHES_KEY] || []).filter((s) => s.enabled !== false && s.url);
  for (const s of list) {
    // ברצף, טאב אחד בכל פעם - עדין יותר על הדפדפן ועל האתר.
    // eslint-disable-next-line no-await-in-loop
    await checkOneSearchInBackgroundTab(s);
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) runBackgroundCheck();
});
